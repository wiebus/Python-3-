#! /usr/bin/env python3 -OOt
# -*- coding: utf-8 -*-
# Programm : PyGerbAnalyse_B3.py
# Python 3 Programm; Analysator and Display for Gerber Files.
# Autor: Dipl.-Ing. Bernd Wiebus alias DL1EIC
# Uedem/Germany den 23 Dezember 2012
# Lesser GNU-GPL
# contact: bernd.wiebus@gmx.de

"""
Python 3 Programm PyGerbAnalyse_B3.py. Its purpose is to analyse and display Gerber files used at PCB-Production.
Author: Dipl.-Ing. Bernd Wiebus alias DL1EIC, Uedem/Germany 23 December 2012, Lesser GNU-GPL, E-Mail: bernd.wiebus@gmx.de
"""

import tkinter
from tkinter.filedialog import *
from ClassDefBasicAnalysisResults import BasGerbAnalyseDaten  #Class: Set of variables to remember analysed gerber files.
from ClassDefGerberLayer import GerberLayer     #Class: Set of variables to remember the values of dispayed gerber files
import tempfile

def AnalyseGerber():
  """
  Checks wether a choosen file is a readable and useable Gerberfile for this Program.  
  If not, the background of the shown path gets red (#FF0000).
  """
  
  Analyse(GerberFile1)  #Jump to subprogramm to analyse the file. For checking, wether it is usable, you have to first analyse it.
  if GerberFile1.stPfad !="":
    if GerberFile1.bGerber == False:
      PfadanzeigeGerber.configure(background = "#FF0000")
    else:
      PfadanzeigeGerber.configure(background = "#408000")
 
def AnalyseDrill():
  """
  Checks wether a choosen file is a readable and useable Excelon drillfile for this Program.  
  If not, the background of the shown path gets red (#FF0000).
  """
  Analyse(DrillFile1)   #Jump to subprogramm to analyse the file. For checking, wether it is usable, you have to first analyse it.
  if DrillFile1.stPfad !="":
    if DrillFile1.bExcellon == False:
      PfadanzeigeDrill.configure(background = "#FF0000")
    else:
      PfadanzeigeDrill.configure(background = "#408000")
   

def Analyse(Target):
  if Target.stPfad == "":
    return()
  Listanzeige2.delete(0, END)
  Pfadsicherung = Target.stPfad # pfadsicherung, weil bei init der Pfad zurückgesetzt würde.
  Target.Init(Target) # Damit keine alten werte weitergezaehlt werden
  Target.stPfad = Pfadsicherung
  Target.Datei = open(Target.stPfad, "rt")
  while True:
    Lesezeile = Target.Datei.readline()
    if len(Lesezeile) ==0:
      break # EOF wenn lesezeile nicht mehr kommt.
    Target.iZeilenzahl = Target.iZeilenzahl + 1
    Gerber247xZeilenzaehlen(Lesezeile, Target)
    Gerber247dZeilenzaehlen(Lesezeile, Target)
    Singleprozzaelen(Lesezeile, Target)
    Startprozzaelen(Lesezeile, Target)
    Siebmayer1000(Lesezeile, Target)
    Siebmayer3000(Lesezeile, Target)
    excellonmetric(Lesezeile, Target)
    excelloninch(Lesezeile, Target)
    excellonfileheaderstart(Lesezeile, Target)
    excellonfileheaderend(Lesezeile, Target)
    excellontoolcode(Lesezeile, Target)
    excellonheaderoff(Lesezeile, Target)
    excellondrilldef(Lesezeile, Target)
    GcodesZeilenzaehlen(Lesezeile, Target)
    G54Codezaehlen(Lesezeile, Target)
    Dcodeszaehlen(Lesezeile, Target)
    DG54codeszaehlen(Lesezeile, Target)
    G01codeszaehlen(Lesezeile, Target)
    G02codeszaehlen(Lesezeile, Target)
    G03codeszaehlen(Lesezeile, Target)
    G10codeszaehlen(Lesezeile, Target)
    G11codeszaehlen(Lesezeile, Target)
    G12codeszaehlen(Lesezeile, Target)
    G74codeszaehlen(Lesezeile, Target)
    G75codeszaehlen(Lesezeile, Target)
    G70codeszaehlen(Lesezeile, Target)
    G71codeszaehlen(Lesezeile, Target)
    G90codeszaehlen(Lesezeile, Target)
    G91codeszaehlen(Lesezeile, Target)
    circlemakroCW1Q(Lesezeile, Target)
    circlemakroCCW1Q(Lesezeile, Target)
    circlemakroCW4Q(Lesezeile, Target)
    circlemakroCCW4Q(Lesezeile, Target)
    MOINcodeszaehlen(Lesezeile, Target)
    MOMMcodeszaehlen(Lesezeile, Target)
    x247FormStatscodeszaehlen(Lesezeile, Target)
    D01codeszaehlen(Lesezeile, Target)
    D02codeszaehlen(Lesezeile, Target)
    D03codeszaehlen(Lesezeile, Target)
    Ncodeszaehlen(Lesezeile, Target)
    Mcodeszaehlen(Lesezeile, Target)
    M00codeszaehlen(Lesezeile, Target)
    M01codeszaehlen(Lesezeile, Target)
    M02codeszaehlen(Lesezeile, Target)
    Ignoredcodeszaehlen(Lesezeile, Target)
    checkcoordinates(Lesezeile, Target)
    ApertureDefinitionsZaehlen(Lesezeile, Target)
    checkNegativeX(Lesezeile, Target)
    checkNegativeY(Lesezeile, Target)       
    
  FileDiscrimination(Target)
  
  stZeilenSchreibzeile =("Analyse of file: " + str(Target.stPfad))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)     
  stZeilenSchreibzeile =("total number of lines: " + str(Target.iZeilenzahl))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("Number of ignored lines: " + str(Target.iIgnoredLines))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  
  if Target.bBogusIndex == True:
    stZeilenSchreibzeile =("More than 20% of lines not recognised! Seems neither to be a Gerber nor a Drill file!")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
    stZeilenSchreibzeile =("BREAK! END OF ANALYSE!")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
    Target.Datei.close()
    return() # stopp, if there is bogus
  
  if Target.bGerber == True and Target.bDrill == True :
    stZeilenSchreibzeile =("Some bogus appears: cannot discriminate wether gerber or drill file.")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
    Target.bBogusIndex2 = True
    
  if Target.bSiebMeyer1000 == True and Target.bSiebMeyer3000 == True :
    stZeilenSchreibzeile =("Some bogus appears: cannot discriminate wether sieb+meyer 1000 or 3000")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
    Target.bBogusIndex2 = True
  
  if Target.bBogusIndex2 == True:
    stZeilenSchreibzeile =("BREAK! END OF ANALYSE!")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
    Target.Datei.close()
    return() # stopp, if there is bogus
    
  stZeilenSchreibzeile =("Gerber247x Zeilen: " + str(Target.iGerber247xzeilen))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("Gerber247d Zeilen: " + str(Target.iGerber247dzeilen))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("Lines starting with  `%` sign: " + str(Target.iProzCode))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  
  if Target.bGerber247x == True :
    stZeilenSchreibzeile =("Seems to be a Gerber247X File.")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
    
  if Target.bGerber247d == True :
    stZeilenSchreibzeile = ("Seems to be a Gerber247D File.")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
   
  if Target.bGerber247x == False and Target.bGerber247d == False :
    stZeilenSchreibzeile = ("Seems to be NOT a Gerber File.")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
    
  if Target.bDrill == True :
    stZeilenSchreibzeile = ("Seems to be a drill File.")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  
  
  if Target.bExcellon == True :
    stZeilenSchreibzeile = ("Seems to be an Excellon drill file.")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  
  if Target.bSiebMeyer1000 == True :
    stZeilenSchreibzeile = ("Seems to be a Sieb + Meyer 1000 drill file.")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  
  if Target.bSiebMeyer3000 == True :
    stZeilenSchreibzeile = ("Seems to be a Sieb + Meyer 3000 drill file.")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
    
  if Target.bGerber247d == True or Target.bGerber247x == True :
    stZeilenSchreibzeile = ("Analyse of Gerber File:")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
   

  if Target.bProzCode == True:
    stZeilenSchreibzeile =("First line containes only a single `%` sign: Indication for an Excellon drill file.")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  if Target.bProzProz1000Code == True:
    stZeilenSchreibzeile =("First line containes only `%%1000`: Indication for a sieb&Meyer 1000 drill file.")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  if Target.bProzProz3000Code == True:
    stZeilenSchreibzeile =("First line containes only `%%3000`: Indication for a sieb&Meyer 3000 drill file.")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  if Target.iMCodes71 >= 1:
    stZeilenSchreibzeile =("Lines found with Excellon metric mode (M71) code: Indication for an Excellon drill file.")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  if Target.iMCodes72 >= 1:
    stZeilenSchreibzeile =("Lines found with Excellon inch mode (M72) code: Indication for an Excellon drill file.")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  if Target.bExcelMetric == True:
    if Target.bExcelInch == True:
      stZeilenSchreibzeile =("WARNING: Different modes (metric and inch) found!")
      Listanzeige2.insert(END, stZeilenSchreibzeile)
      Listanzeige2.yview(END)
  if Target.iMCodes48 >= 1:
    stZeilenSchreibzeile =("Excellon file header (M48)  start code found: Indication for an Excellon drill file.")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  if Target.iMCodes95 >= 1:
    stZeilenSchreibzeile =("Excellon file header (M95) end code found: Indication for an Excellon drill file.")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  if Target.iTCodes >= 1:
    stZeilenSchreibzeile =("Lines starting with `T` found: " + str(Target.iTCodes) + " Indication for a drill file.")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  if Target.iTDef >= 1:
    stZeilenSchreibzeile =("Lines starting with `T` in Excellon header as drill definitions found: " + str(Target.iTCodes) + " Indication for an Excellon drill file.")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  if Target.iKoordinatenD01 >= 1:
    stZeilenSchreibzeile =("Koordinate lines with D01 code (with light): " + str(Target.iKoordinatenD01))
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  if Target.iKoordinatenD02 >= 1:
    stZeilenSchreibzeile =("Koordinate lines with D02 code (without light): " + str(Target.iKoordinatenD02))
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  if Target.iKoordinatenD03 >= 1:
    stZeilenSchreibzeile =("Koordinate lines with D03 code (blinks): " + str(Target.iKoordinatenD03))
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  if Target.iApertDef >= 1:
    stZeilenSchreibzeile =("Extentendet Gerber aperture definitions found: " + str(Target.iApertDef))
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  if Target.iApertDef == 0:
    stZeilenSchreibzeile =("NO extentendet Gerber aperture definitions found!")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  if Target.bNegXCoordinates == True:
    stZeilenSchreibzeile =("Negative X coordinates found!")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
  if Target.bNegYCoordinates == True:
    stZeilenSchreibzeile =("Negative Y coordinates found!")
    Listanzeige2.insert(END, stZeilenSchreibzeile)
    Listanzeige2.yview(END)
    
  stZeilenSchreibzeile =("G-Code Zeilen: " + str(Target.iGCodes))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("G54-Code (Prepare tool) Zeilen: " + str(Target.iGCode54))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("D-Code Zeilen: " + str(Target.iDCodes))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("D-Code Zeilen mit vorangegangenem G54 (Tool prepare): " + str(Target.iDCodesTP))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("G01-Code (1x linear mode) Zeilen : " + str(Target.iGCode01))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("G02-Code (clockwise mode) Zeilen : " + str(Target.iGCode02))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("G03-Code (counter clockwise mode) Zeilen : " + str(Target.iGCode03))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("G10-Code (10x linear mode) Zeilen : " + str(Target.iGCode10))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("G11-Code (0,1x linear mode) Zeilen : " + str(Target.iGCode11))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("G12-Code (0,01x linear mode) Zeilen : " + str(Target.iGCode12))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("G74-Code (single quadrant mode) Zeilen : " + str(Target.iGCode74))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("G75-Code (multi quadrant mode) Zeilen : " + str(Target.iGCode75))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("G70-Code (inch mode) Zeilen : " + str(Target.iGCode70))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("G71-Code (mm mode) Zeilen : " + str(Target.iGCode71))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("G90-Code (absolute mode) Zeilen : " + str(Target.iGCode90))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("G91-Code (relative mode) Zeilen : " + str(Target.iGCode91))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("MOIN Statement (247x inch mode) Zeilen : " + str(Target.iMoin))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("MOMM Statement (247x inch mode) Zeilen : " + str(Target.iMomm))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("FS 247x Format Statement Zeilen : " + str(Target.iFS))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("247x Format statement : " + Target.stFS)
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("247x Format statement interpretation absolute mode gefunden : " + str(Target.iFSAbsolute))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("247x Format statement interpretation inkremental mode gefunden : " + str(Target.iFSIncremental))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("D01 (Zuege mit Licht) Statements : " + str(Target.iDCode01))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("D02 (Zuege ohne Licht) Statements : " + str(Target.iDCode02))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("D03 (Blinks/Flashes/Blitze) Statements : " + str(Target.iDCode03))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("N-Code Zeilen : " + str(Target.iNCodes))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("M-Code Zeilen : " + str(Target.iMCodes))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("M00-Code (Gerber code start) Zeilen : " + str(Target.iMCodes0))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("Letzter M00-Code (Gerber code start) in Zeile Nr. : " + str(Target.iMCodes0Line))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("M01-Code (Gerber code stop) Zeilen : " + str(Target.iMCodes1))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("M02-Code (Gerber code end) Zeilen : " + str(Target.iMCodes2))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("Letzter M02-Code (Gerber code end) in Zeile Nr. : " + str(Target.iMCodes2Line))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  stZeilenSchreibzeile =("Ignored Code Zeilen : " + str(Target.iIgnoredLines))
  Listanzeige2.insert(END, stZeilenSchreibzeile)
  Listanzeige2.yview(END)
  Target.Datei.close()
  
def ApertureDefinitionsZaehlen(Lesestring, Target):  #Counting Aperture definitions for extended gerber (lines starting with "%AD")
  if Lesestring.startswith("%AD") and Lesestring.endswith("*%\n") or Lesestring.endswith("*%"):
    Target.iApertDef = Target.iApertDef + 1
def Gerber247xZeilenzaehlen(Lesestring, Target): #Checking for %~~~~~~~~*% lines as indiz for gerber247x, and incrementation of the 247x counter. 
  if Lesestring.startswith("%") and Lesestring.endswith("*%\n") or Lesestring.endswith("*%"):
    Target.iGerber247xzeilen = Target.iGerber247xzeilen + 1 
def Gerber247dZeilenzaehlen(Lesestring, Target): #Checking for ~~~~* lines as indiz for gerber247d, and incrementation of the 247d counter. 
  if Lesestring.endswith("*\n") or Lesestring.endswith("*"):
      Target.iGerber247dzeilen = Target.iGerber247dzeilen + 1
def Singleprozzaelen(Lesestring, Target):  #Checking for single % lines as indiz for Excellon drill file. 
  if  Lesestring ==("%\n") or Lesestring ==("%"):
    if Target.iZeilenzahl == 1: #And checking, wether it is in the first line.
      Target.bProzCode = True
def Startprozzaelen(Lesestring, Target):  #Checking for lines starting with `%`. 
  if  Lesestring.startswith("%"):               
    Target.iProzCode = Target.iProzCode + 1
    if Target.iZeilenzahl == 1: #And checking, wether first line is a % line.
      Target.bStartProzCode = True
  
def Siebmayer1000(Lesestring, Target):  #Checking for a %%1000 line as indiz for Sieb&Meyer 1000 drill file. 
  if  Lesestring == "%%1000\n" :
    if Target.iZeilenzahl == 1: #And checking, wether first line is a %%1000 line.
      Target.bProzProz1000Code = True
def excellonmetric(Lesestring, Target):     #Checking for lines starting with M71 for Excellon drill File metric definition
  if  Lesestring.startswith("M71"):
    Target.iMCodes71 = Target.iMCodes71 + 1
    Target.bExcelMetric = True #Switch on/Off Excellon unit modes
    Target.bExcelInch = False
def excelloninch(Lesestring, Target):     #Checking for lines starting with M72 for Excellon drill File inch definition
  if  Lesestring.startswith("M72"):
    Target.iMCodes72 = Target.iMCodes72 + 1
    Target.bExcelInch = True  #Switch on/Off Excellon unit modes
    Target.bExcelHeader = False
def excellonfileheaderstart(Lesestring, Target):     #Checking for lines starting with M48 for Ecellon drill File header start
  if  Lesestring.startswith("M48"):
    Target.iMCodes48 = Target.iMCodes48 + 1
    Target.bExcelHeader = True  #Switch on/Off Excellon header mode
def excellonfileheaderend(Lesestring, Target):     #Checking for lines starting with M95 for Ecellon drill File header end
  if  Lesestring.startswith("M95"):
    Target.iMCodes95 = Target.iMCodes95 + 1
    Target.bExcelHeader = False  #Switch on/Off Excellon header mode
def excellonheaderoff(Lesestring, Target):     #Checking for single `%` lines during Ecellon header mode. Empirical header mode switch off argument.
  if  Lesestring =="%\n":
    if Target.bExcelHeader == True: #Switch off Excellon header mode
      Target.bExcelHeader = False
      Target.bExcelHeaderProzOff = True
def excellontoolcode(Lesestring, Target):     #Checking for lines starting with T as indiz for Ecellon drill File
  if  Lesestring.startswith("T"):
    Target.iTCodes = Target.iTCodes + 1
def excellondrilldef(Lesestring, Target):     #Checking for lines starting with T within a header (Drill definitions)
  if  Lesestring.startswith("T"):
    if Target.bExcelHeader == True:
      Target.iTDef = Target.iTDef + 1
def Siebmayer3000(Lesestring, Target):  #Checking for a %%3000 line as indiz for Sieb&Meyer 1000 drill file. 
  if  Lesestring == "%%3000\n" :
    if Target.iZeilenzahl == 1: #And checking, wether first line is a %%1000 line.
      Target.bProzProz3000Code = True
def GcodesZeilenzaehlen(Lesestring, Target):  #Checking for leading G and incrementation of the G-Code counter.
  if  Lesestring.startswith("G"):
    Target.iGCodes = Target.iGCodes + 1     
def G54Codezaehlen(Lesestring, Target): #Checking and Counting of tool prepare command (G54, 247D).
  if Lesestring.startswith("G54"):
    Target.iGCode54 = Target.iGCode54 + 1
def Dcodeszaehlen(Lesestring, Target): # Checking for leading D and incrementation of the D-Code counter.
  if Lesestring.startswith("D"):
    Target.iDCodes = Target.iDCodes + 1
def DG54codeszaehlen(Lesestring, Target): #Checking for D-Codes with tool prepare leading.
  if Lesestring.startswith("G54D"):
    Target.iDCodesTP = Target.iDCodesTP + 1
def G01codeszaehlen(Lesestring, Target):   #Checking and counting of 1x linear mode (G01, 247D).
                                   #This mode is only for gerber data.
                                   #maybe this data use is modal.
  if Lesestring.startswith("G01"):
    Target.iGCode01 = Target.iGCode01 + 1
    Target.bGCode02 = False
    Target.bGCode03 = False
    Target.bGCode01 = True
    Target.bGCode10 = False
    Target.bGCode11 = False
    Target.bGCode12 = False
    Target.bGCode74 = False
    Target.bGCode75 = False
    Target.bCircleMakro = False
    Transferstring = Lesestring   #Preparing for cheking wether Koordinates follow
    Transferstring = Transferstring[3:] #cutting away the leading G01
    checkNegativeX(Transferstring, Target) #checking for negative Koordinates
    checkNegativeY(Transferstring, Target) #checking for negative Koordinates
    checkcoordinates(Transferstring, Target) #checking Koordinates
    
    
def G02codeszaehlen(Lesestring, Target):   #Checking and counting of Clockwise mode (G02, 247D)(circle tool).
                                   #This mode is only for gerber data.
                                   #maybe this data use is modal.
  if Lesestring.startswith("G02"):
    Target.iGCode02 = Target.iGCode02 + 1
    Target.bGCode02 = True
    Target.bGCode03 = False
    Target.bGCode01 = False
    Target.bGCode10 = False
    Target.bGCode11 = False
    Target.bGCode12 = False
    Target.bCircleMakro = True
def G03codeszaehlen(Lesestring, Target):   #Checking and counting of counter clockwise mode (G03, 247D)(circle tool).
                                   #This mode is only for gerber data.
                                   #maybe this data use is modal.
  if Lesestring.startswith("G03"):
    Target.iGCode03 = Target.iGCode03 + 1
    Target.bGCode02 = False
    Target.bGCode03 = True
    Target.bGCode01 = False
    Target.bGCode10 = False
    Target.bGCode11 = False
    Target.bGCode12 = False
    Target.bCircleMakro = True
def G10codeszaehlen(Lesestring, Target):   #Checking and counting of 10x linear mode (G10, 247D).
                                   #This mode is only for gerber data.
                                   #maybe this data use is modal.
  if Lesestring.startswith("G10"):
    Target.iGCode10 = Target.iGCode10 + 1
    Target.bGCode02 = False
    Target.bGCode03 = False
    Target.bGCode01 = False
    Target.bGCode10 = True
    Target.bGCode11 = False
    Target.bGCode12 = False
    Target.bGCode74 = False
    Target.bGCode75 = False
    Target.bCircleMakro = False
def G11codeszaehlen(Lesestring, Target):   #Checking and counting of 0,1x linear mode (G11, 247D).
                                   #This mode is only for gerber data.
                                   #maybe this data use is modal.
  if Lesestring.startswith("G11"):
    Target.iGCode11 = Target.iGCode11 + 1
    Target.bGCode02 = False
    Target.bGCode03 = False
    Target.bGCode01 = False
    Target.bGCode10 = False
    Target.bGCode11 = True
    Target.bGCode12 = False
    Target.bGCode74 = False
    Target.bGCode75 = False
    Target.bCircleMakro = False
def G12codeszaehlen(Lesestring, Target):   #Checking and counting of 0,01x linear mode (G12, 247D).
                                   #This mode is only for gerber data.
                                   #maybe this data use is modal.
  if Lesestring.startswith("G12"):
    Target.iGCode12 = Target.iGCode12 + 1
    Target.bGCode02 = False
    Target.bGCode03 = False
    Target.bGCode01 = False
    Target.bGCode10 = False
    Target.bGCode11 = False
    Target.bGCode12 = True
    Target.bGCode74 = False
    Target.bGCode75 = False
    Target.bCircleMakro = False
def G74codeszaehlen(Lesestring, Target):   #Checking and counting of single quadrant mode (G74, 247D)(circle tool).
                                   #This mode is only for gerber data.
                                   #maybe this data use is modal.
  if Lesestring.startswith("G74"):
    Target.iGCode74 = Target.iGCode74 + 1
    Target.bGCode01 = False
    Target.bGCode10 = False
    Target.bGCode11 = False
    Target.bGCode12 = False
    Target.bGCode74 = True
    Target.bGCode75 = False
    Target.bCircleMakro = False
def G75codeszaehlen(Lesestring, Target):   #Checking and counting of circle tool mode (G75, 247D)(circle tool).
                                   #This mode is only for gerber data.
                                   #maybe this data use is modal.
  if Lesestring.startswith("G75"):
    Target.iGCode75 = Target.iGCode75 + 1
    Target.bGCode01 = False
    Target.bGCode10 = False
    Target.bGCode11 = False
    Target.bGCode12 = False
    Target.bGCode74 = False
    Target.bGCode75 = True
    Target.bCircleMakro = True
def circlemakroCW1Q(Lesestring, Target):    #Means gerber circle makro found.
  if Target.bGCode02 == True:
    if Target.bGCode74 == True:
      Target.bCircleMakro = True
def circlemakroCCW1Q(Lesestring, Target):    #Means gerber circle makro found.
  if Target.bGCode03 == True:
    if Target.bGCode74 == True:
      Target.bCircleMakro = True
def circlemakroCW4Q(Lesestring, Target):    #Means gerber circle makro found.
  if Target.bGCode02 == True:
    if Target.bGCode75 == True:
      Target.bCircleMakro = True
def circlemakroCCW4Q(Lesestring, Target):    #Means gerber circle makro found.
  if Target.bGCode03 == True:
    if Target.bGCode75 == True:
      Target.bCircleMakro = True
def G70codeszaehlen(Lesestring, Target):   #Checking and Counting of inch specifyings (G70, 247D). 
                                   #maybe this data use is modal.
  if Lesestring.startswith("G70"):
    Target.iGCode70 = Target.iGCode70 + 1
    Target.bEinheitinch = True
    Target.bEinheitmm = False
def G71codeszaehlen(Lesestring, Target):   #Checking and Counting of mm specifyings (G70, 247D). 
                                   #maybe this data use is modal.
  if Lesestring.startswith("G71"):
    Target.iGCode71 = Target.iGCode71 + 1
    Target.bEinheitinch = False
    Target.bEinheitmm = True
def G90codeszaehlen(Lesestring, Target):   #Checking and Counting of absolute specifyings (G90, 247D). 
                                   #maybe this data use is modal.
  if Lesestring.startswith("G90"):
    Target.iGCode90 = Target.iGCode90 + 1
    Target.bAbsolute = True
    Target.bIncremental = False
def G91codeszaehlen(Lesestring, Target):   #Checking and Counting of relative specifyings (G90, 247D). 
                                   #maybe this data use is modal.
  if Lesestring.startswith("G91"):
    Target.iGCode91 = Target.iGCode91 + 1
    Target.bIncremental = True
    Target.bAbsolute = False
def MOINcodeszaehlen(Lesestring, Target): #Checking and Counting of inch specifyings (%MOIN, 247X).
                                  #maybe this data use is modal.
  if Lesestring.startswith("%MOIN"):
    Target.iMoin = Target.iMoin + 1
    Target.bEinheitinch = True
    Target.bEinheitmm = False
def MOMMcodeszaehlen(Lesestring, Target): #Checking and Counting of mm specifyings (%MOIN, 247X).
                                  #maybe this data use is modal.
  if Lesestring.startswith("%MOMM"):
    Target.iMomm = Target.iMomm + 1
    Target.bEinheitinch = False
    Target.bEinheitmm = True
def x247FormStatscodeszaehlen(Lesestring, Target): #Checking and Counting 247x Format statements (%FS).
  if Lesestring.startswith("%FS"):
    Target.iFS = Target.iFS + 1
    Target.stFS = Lesestring #preserving format statment
    stLesezeichen = Lesestring[4]
    if stLesezeichen == "A" : #Testen auf absolute mode
      Target.iFSAbsolute = Target.iFSAbsolute + 1
      Target.bAbsolute = True
      Target.bIncremental = False
    if stLesezeichen == "I" : #Testen auf inkremental mode
      Target.iFSIncremental = Target.iFSIncremental + 1
      Target.bIncremental = True
      Target.bAbsolute = False
def D01codeszaehlen(Lesestring, Target): #Checking for leading D01 and incrementation of the D01-Code counter. Mode Setting.
                                 #D01 means draws with light.
                                 #D02 means draws without light.
                                 #D03 means short blinks or flashes.
  if Lesestring.startswith("D01"):
    Target.iDCode01 = Target.iDCode01 + 1
    Target.bModeD01 = True
    Target.bModeD02 = False
    Target.bModeD03 = False
    
    
def D02codeszaehlen(Lesestring, Target): #Checking for leading D01 and incrementation of the D01-Code counter. Mode Setting.
                                 #D01 means draws with light.
                                 #D02 means draws without light.
                                 #D03 means short blinks or flashes.
  if Lesestring.startswith("D02"):
    Target.iDCode02 = Target.iDCode02 + 1
    Target.bModeD01 = False
    Target.bModeD02 = True
    Target.bModeD03 = False
  
def D03codeszaehlen(Lesestring, Target): #Checking for leading D01 and incrementation of the D01-Code counter. Mode Setting.
                                 #D01 means draws with light.
                                 #D02 means draws without light.
                                 #D03 means short blinks or flashes.
  if Lesestring.startswith("D03"):
    Target.iDCode03 = Target.iDCode03 + 1
    Target.bModeD01 = False
    Target.bModeD02 = False
    Target.bModeD03 = True
    
def Ncodeszaehlen(Lesestring, Target): #Checking for leading N and incrementation of the N-Code counter..
  if Lesestring.startswith("N"):
    Target.iNCodes = Target.iNCodes + 1
def Mcodeszaehlen(Lesestring, Target): #Checking for leading M and incrementation of the M-Code counter.
  if Lesestring.startswith("M"):
    Target.iMCodes = Target.iMCodes + 1
def M00codeszaehlen(Lesestring, Target): #Checking for leading M00 (Gerber file start) and incrementation of the startcode counter.
                                 #Also storage of the linenumber of this M00-Code.
  if Lesestring.startswith("M00"):
    Target.iMCodes0 = Target.iMCodes0 + 1
    Target.iMCodes0Line = Target.iZeilenzahl
def M01codeszaehlen(Lesestring, Target): #Checking for leading M01 (Gerber program stop) and increment of the stopcode counter.
  if Lesestring.startswith("M01"):
    Target.iMCodes1 = Target.iMCodes1 + 1
def M02codeszaehlen(Lesestring, Target): #Checking for leading M02 (Gerber file end) and incrementation of the endcode counter.
                                 #Also storage of the linenumber of this M02-Code.
  if Lesestring.startswith("M02"):
    Target.iMCodes2 = Target.iMCodes2 + 1
    Target.iMCodes2Line = Target.iZeilenzahl
def Ignoredcodeszaehlen(Lesestring, Target): #Checking and counting of ignored lines starting NOT with %, D, G, N, M, X or Y.
                                     #Stub: Handling of lines starting with T missing.
  if Lesestring.startswith("%"):
    return()
  if Lesestring.startswith("D") or  Lesestring.startswith("d"):
    return()
  if Lesestring.startswith("G") or  Lesestring.startswith("g"):
    return()
  if Lesestring.startswith("N") or  Lesestring.startswith("n"):
    return()
  if Lesestring.startswith("M") or  Lesestring.startswith("m"):
    return()
  if Lesestring.startswith("T") or  Lesestring.startswith("t"):
    return()
  if Lesestring.startswith("X") or  Lesestring.startswith("x"):
    return()
  if Lesestring.startswith("Y") or  Lesestring.startswith("y"):
    return()
  Target.iIgnoredLines = Target.iIgnoredLines + 1
def checkcoordinates(Lesestring, Target):   #Checking and counting of lines starting with X or Y....
  if Lesestring.startswith("X") or Lesestring.startswith("Y") or Lesestring.startswith("x") or Lesestring.startswith("y"):
    Target.iKoordinatenLines = Target.iKoordinatenLines + 1
    if Lesestring.endswith("D01*\n"):  #..and ending with D01* as coordinate lines for moves with light.
      Target.iKoordinatenD01 = Target.iKoordinatenD01 + 1
      Target.bModeD01 = True
      Target.bModeD02 = False
      Target.bModeD03 = False
    if Lesestring.endswith("D02*\n"):  #....and ending with D02* as coordinate lines for moves without light
      Target.iKoordinatenD02 = Target.iKoordinatenD02 + 1
      Target.bModeD01 = False
      Target.bModeD02 = True
      Target.bModeD03 = False
    if Lesestring.endswith("D03*\n"):  #......and ending with D03* as coordinate lines for blinks
      Target.iKoordinatenD03 = Target.iKoordinatenD03 + 1
      Target.bModeD01 = False
      Target.bModeD02 = False
      Target.bModeD03 = True
        #Set Warning marker if no D01, D02 or D03 Mode activated with coodinates.
  if Target.bModeD01 == False and Target.bModeD02 == False and Target.bModeD03 == False: 
    Target.bExposeWarning = True
              #Set Warning marker if no inch or mm Mode activated with coodinates.
  if Target.bEinheitinch == False and Target.bEinheitmm == False and Target.bModeD03 == False:
    Target.bUnitWarning = True
           #Set Warning marker if no Absolute or incremental Mode activated with coodinates.
  if Target.bAbsolute == False and Target.bIncremental == False and Target.bModeD03 == False:
    Target.bAbsIncWarning = True
    
def checkNegativeX(Lesestring, Target): # checking for negative X coordinates
  if Lesestring.startswith("X") or Lesestring.startswith("Y") or Lesestring.startswith("x") or Lesestring.startswith("y"):
    if Lesestring.find("X-") >= 0 or Lesestring.find("x-") >= 0: #Because string.find(substring) gifes position of substring.
      Target.bNegXCoordinates = True
    
def checkNegativeY(Lesestring, Target): # checking for negative Y coordinates
  if Lesestring.startswith("X") or Lesestring.startswith("Y") or Lesestring.startswith("x") or Lesestring.startswith("y"):
    if Lesestring.find("Y-") >= 0 or Lesestring.find("y-") >= 0: #Because string.find(substring) gifes position of substring.
      Target.bNegYCoordinates = True


# Analyse speichern 
def saveanalyse():
     name = asksaveasfilename()
     if name: #Nur Wahr, wenn Pfad gewählt wurde. Sonst Leerstring/Tupel
          AnalyseList1 = open(name , "w")
          Listenlaenge =  Listanzeige2.size()
          for iIndex in range(Listenlaenge):
               Schreibzeile = (Listanzeige2.get(iIndex) +"\n")
               AnalyseList1.write(Schreibzeile)
          AnalyseList1.close()




  
  
  
# Funktion zum button Clear
def clear():
  Listanzeige1.delete(0, END) #Clear list 1.
  Listanzeige2.delete(0, END) #Clear list2.
  
  global name
  name = ""
  PfadanzeigeGerber.delete(0, END)
  PfadanzeigeGerber.insert(0, "Gerber Path: Empty")
  GerberFile1.Init(GerberFile1)
  PfadanzeigeGerber.configure(background = "#408000")
  #for iIndex in range(0, GerberFile1Processed.iGerberLayerListLen -1, 1): #For all elements of list....
  #  del GerberFile1Processed.liGerberLayerList[0] #delete them
 
  PfadanzeigeDrill.delete(0, END)
  PfadanzeigeDrill.insert(0, "Drill Path: Empty")
  DrillFile1.Init(DrillFile1)
  PfadanzeigeDrill.configure(background = "#408000")
  

# Funktion zu Button Ende
def ende():
  
  Hauptfenster.destroy()
    # Hauptfenster.quit
     

# Funktion zum Button About
def about():
  #Funktion Schliessen Aboutfenster
  def aboutok():
    Aboutfenster.destroy()
          
  Programmname ="GerbAnalyse B3: "
  Programmzweck ="Programm zur Analyse von Gerberfiles. \n"
  Programmversion ="Version B3 (Alpha) "
  Programmdatum ="Date: 23 Dezember 2012 \n"
  Programmauthor ="Author: Dipl.-Ing. Bernd Wiebus \n"
  EMailauthor = "E-Mail: bernd.wiebus@gmx.de \n"
  Programmlizenz ="Lesser GNU-GPL NO WARRANTY!"
  
  Programmabout = Programmname + Programmzweck + Programmversion + Programmdatum + Programmauthor + EMailauthor +Programmlizenz
  Aboutfenster = tkinter.Tk()
  Aboutfenster.title ("About GerbAnalyse_B3")
  Aboutanzeige = tkinter.Label(Aboutfenster, text = Programmabout, background = "#408000",foreground = "#FFFF5F")
  Aboutanzeige.pack(side = TOP, fill = X)
  # Rahmen für Aboutfenster OK Button
  AboutRahmen1 = Frame(Aboutfenster, background = "#002040")
  AboutRahmen1.pack(side = TOP, fill = X)
  # Button Aboutok
  buttonaboutok = tkinter.Button(AboutRahmen1, text = "OK", background = "#304000",  foreground = "#FFFF5F", command = aboutok)
  buttonaboutok.pack(side = TOP)
    
    

# Funktion Dateiauswahl Gerberfile
def Dateiwahl():
  GerberFile1.Init(GerberFile1)
  global name
  stGerberName = askopenfilename()
  if stGerberName: #Only true, if path choosen, else empty string/tupel.
    GerberFile1.stPfad = stGerberName
    GerberFile1.iZeilenzahl = 0
    Pfad = ("Path: " + stGerberName)
    PfadanzeigeGerber.delete(0, END)
    PfadanzeigeGerber.insert(0, Pfad)
    Listanzeige1.delete(0, END) #New file, so clear old listing. 
    Listanzeige2.delete(0, END) #New file, so clear old listing. 
    GerberList1 = open(GerberFile1.stPfad, mode="rt")
    while True:
      Lesezeile = GerberList1.readline()
      if len(Lesezeile) ==0:
        break # EOF wenn lesezeile nicht mehr kommt.
      Listanzeige1.insert(END, Lesezeile) #Neues Listimng
      Listanzeige1.yview(END) #Anzeige zum Ende
    GerberList1.close()
    return()
          
def Drillfile():
  DrillFile1.Init(DrillFile1)
  stDrillName = ""
  stDrillName= askopenfilename()
  if stDrillName: #Only true, if path choosen, else empty string/tupel.
    DrillFile1.stPfad = stDrillName
    DrillFile1.iZeilenzahl = 0
    Pfad = ("Pfad: " + stDrillName)
    PfadanzeigeDrill.delete(0, END)
    PfadanzeigeDrill.insert(0, Pfad)
    Listanzeige1.delete(0, END) #New file, so clear old listing. 
    Listanzeige2.delete(0, END) #New file, so clear old listing. 
    DrillList1 = open(DrillFile1.stPfad, mode="rt")
    while True:
      Lesezeile = DrillList1.readline()
      if len(Lesezeile) ==0:
        break # EOF wenn lesezeile nicht mehr kommt.
      Listanzeige1.insert(END, Lesezeile) #Neues Listimng
      Listanzeige1.yview(END) #Anzeige zum Ende
    DrillList1.close()
    return()
     

def DisplayWindowOeffnen():
  Analyse(GerberFile1)
  Analyse(DrillFile1)
  AnalyseGerber()  #Checking, wether the file for gerber is a void gerber file
  AnalyseDrill()  #Checking, wether the file for drill is a void excellon drill file
  GerberFile1Processed.bShowMoves = False
  GerberFile1Processed.bShowDraws = True
  GerberFile1Processed.bShowBlinks = True
  GerberFile1Processed.bShowDrills = True
  
  #Display Gerber and drill data graphical
  def GerbDisplay():
    stXKoordinate = ""
    stYKoordinate = ""
    stTeststring = ""
    iXKoordinate = 0
    iXKoordinateAlt = 0
    fXKoordinate = 0.0
  
    iYKoordinate = 0
    iYKoordinateAlt = 0
    fYKoordinate = 0.0
  
    iXKoordinateMaxValue = 1
    iYKoordinateMaxValue = 1
    iYMaxValue = 1  # Used for standard mirroring at x axis, because gerber counts y values upward, and canvases donward
    Lesestring = ""
    stLesestring = ""
    stDraw = ""
    tuKoordinatentupel =("", 0, 0, 0, 0)
  
    fZoomXLoc = GerberFile1Processed.fZoomX
    fZoomYLoc = GerberFile1Processed.fZoomY
    fZoomLoc = GerberFile1Processed.fZoom  
    iYMaxValue = GerberFile1Processed.iYMaxKoordinate  + GerberFile1Processed.yShift + 100
    iFaktor = 0
    iItemzaehler = 0
    
    
    if GerberFile1Processed.iGerberLayerListLen > 0:
        
      for iIndex in range(0, GerberFile1Processed.iGerberLayerListLen, 1):
        GerberFile1Processed.liGerberLayerLine = GerberFile1Processed.liGerberLayerList[iIndex]
        
        iXKoordinateAlt = iXKoordinate
        iYKoordinateAlt = iYKoordinate
      
        stItemNummer = GerberFile1Processed.liGerberLayerLine[1]
        stDraw = GerberFile1Processed.liGerberLayerLine[2]
        iXKoordinate = GerberFile1Processed.liGerberLayerLine[3] + GerberFile1Processed.xShift + 100
        iYKoordinate = GerberFile1Processed.liGerberLayerLine[4] + GerberFile1Processed.yShift + 100
        
        iYKoordinate = iYMaxValue - iYKoordinate # standard mirroring y values
        
      
      
        fXKoordinate = int(iXKoordinate) * fZoomLoc
        fYKoordinate = int(iYKoordinate) * fZoomLoc
        iXKoordinate = int(fXKoordinate)
        iYKoordinate = int(fYKoordinate)
      
        if stDraw.startswith("T")and GerberFile1Processed.bShowDrills == True:
          caDisplay.create_line( iXKoordinate - 3, iYKoordinate - 3, iXKoordinate + 3, iYKoordinate + 3, fill="green", width = 1,tags = "Drill")
          caDisplay.create_line( iXKoordinate - 3, iYKoordinate + 3, iXKoordinate + 3, iYKoordinate - 3, fill="green", width = 1,tags = "Drill")
        
        if stDraw == "D01" and GerberFile1Processed.bShowDraws == True :
          caDisplay.create_line(iXKoordinateAlt, iYKoordinateAlt, iXKoordinate, iYKoordinate, fill="red", width = 1, tags = "Draw")
        if stDraw == "D02" and GerberFile1Processed.bShowMoves == True :
          caDisplay.create_line(iXKoordinateAlt, iYKoordinateAlt, iXKoordinate, iYKoordinate, fill="grey", width = 1, tags = "Move")
        if stDraw == "D03" and GerberFile1Processed.bShowBlinks == True :
          caDisplay.create_oval ( iXKoordinate - 3, iYKoordinate - 3, iXKoordinate + 3, iYKoordinate + 3, fill="blue", width = 1, tags = "Blink")
          
    caDisplay.config(yscrollcommand=scrollbar1Senk.set, xscrollcommand=scrollbar1Wag.set)
    
    stXKoordinate = ""
    stYKoordinate = ""
    stTeststring = ""
    iXKoordinate = 0
    iXKoordinateAlt = 0
    fXKoordinate = 0.0
  
    iYKoordinate = 0
    iYKoordinateAlt = 0
    fYKoordinate = 0.0
    iYMaxValue = 1
    iXKoordinateMaxValue = 1
    iYKoordinateMaxValue = 1
    Lesestring = ""
    stLesestring = ""
    stDraw = ""
    tuKoordinatentupel =("", 0, 0, 0, 0)
    fZoomXLoc = DrillFile1Processed.fZoomX
    fZoomYLoc = DrillFile1Processed.fZoomY
    
    
    if DrillFile1Processed.bSyncronise == False:
      fZoomLoc = DrillFile1Processed.fZoom
      iYMaxValue = DrillFile1Processed.iYMaxKoordinate  + DrillFile1Processed.yShift + 100
    if DrillFile1Processed.bSyncronise == True:
      fZoomLoc = GerberFile1Processed.fZoom
      iYMaxValue = GerberFile1Processed.iYMaxKoordinate  + GerberFile1Processed.yShift + 100
    iFaktor = 0
    #iItemzaehler = 0 
    
    
    for iIndex in range(0, DrillFile1Processed.iGerberLayerListLen, 1):
     
      DrillFile1Processed.liGerberLayerLine = DrillFile1Processed.liGerberLayerList[iIndex]
      
    
      iXKoordinateAlt = iXKoordinate
      iYKoordinateAlt = iYKoordinate
    
      stItemNummer = DrillFile1Processed.liGerberLayerLine[1]
      stDraw = DrillFile1Processed.liGerberLayerLine[2]
      if DrillFile1Processed.bSyncronise == False:
        iXKoordinate = DrillFile1Processed.liGerberLayerLine[3] + DrillFile1Processed.xShift + 100
        iYKoordinate = DrillFile1Processed.liGerberLayerLine[4] + DrillFile1Processed.yShift + 100
      if DrillFile1Processed.bSyncronise == True:
        iXKoordinate = DrillFile1Processed.liGerberLayerLine[3] + GerberFile1Processed.xShift + 100
        iYKoordinate = DrillFile1Processed.liGerberLayerLine[4] + GerberFile1Processed.yShift + 100
      
      iYKoordinate = iYMaxValue - iYKoordinate # standard mirroring y values
      
    
      fXKoordinate = int(iXKoordinate) * fZoomLoc
      fYKoordinate = int(iYKoordinate) * fZoomLoc
      
      iXKoordinate = int(fXKoordinate)
      iYKoordinate = int(fYKoordinate)
    
      if stDraw.startswith("T")and DrillFile1Processed.bShowDrills == True:
        caDisplay.create_line( iXKoordinate - 6, iYKoordinate - 6, iXKoordinate + 6, iYKoordinate + 6, fill="green", width = 1,tags = "Drill")
        caDisplay.create_line( iXKoordinate - 6, iYKoordinate + 6, iXKoordinate + 6, iYKoordinate - 6, fill="green", width = 1,tags = "Drill")
       
    
    caDisplay.config(yscrollcommand=scrollbar1Senk.set, xscrollcommand=scrollbar1Wag.set)
  
  
  def DisplayWindowClose():
    DisplayWindow.destroy()
    
    
  def GerbProcessing(): # Processing Gerber Lines into a list.
    stXKoordinate = ""
    stYKoordinate = ""
    stTeststring = ""
    iXKoordinate = 0
    iXKoordinateAlt = 0
    iYKoordinate = 0
    iYKoordinateAlt = 0
    iXKoordinateMaxValue = 1
    iYKoordinateMaxValue = 1
    iXKoordinateMaxNegValue = 1
    iYKoordinateMaxNegValue = 1
    Lesestring = ""
    stLesestring = ""
    stDraw = ""
    tuKoordinatentupel =("", 0, 0, 0, 0)
    iLinienzaehler = 0
    iKoordinatenlinienzaehler = 0
    liGerberLayerLineLocal = [0, "", "", 0, 0,]
    bNewDrawBlink = False
    iItemzaehler = 0
  

    GerberFile1Processed.iGerberLayerListLen = len(GerberFile1Processed.liGerberLayerList)
    for iIndex in range(0, GerberFile1Processed.iGerberLayerListLen -1, 1): #Clear the old list
    
     
      del GerberFile1Processed.liGerberLayerList[0]
      iListLen = len(GerberFile1Processed.liGerberLayerList)
    if GerberFile1.stPfad != "":
      GerberFile1.Datei = open(GerberFile1.stPfad, "rt")
      while True:
        stLesestring = GerberFile1.Datei.readline()
        if len(stLesestring) ==0:
          break # EOF wenn lesezeile nicht mehr kommt.
        iLinienzaehler = iLinienzaehler + 1
        if stLesestring.startswith("G01"): # setting linear mode, maybe, koordinates will follow
          stLesestring = stLesestring[3:]
        if stLesestring.startswith("X") or  stLesestring.startswith("x"):
          bNewDrawBlink = True
          iKoordinatenlinienzaehler = iKoordinatenlinienzaehler + 1
          stLesestring = stLesestring[1:]
          while stLesestring.startswith(" "):
            stLesestring = stLesestring[1:]
          if stLesestring.startswith("-"):
            stXKoordinate = stXKoordinate + "-"
            stLesestring = stLesestring[1:]
          while stLesestring.startswith(" "):
            stLesestring = stLesestring[1:]
          stTeststring = stLesestring[:1]
          while stTeststring.isdigit():
            stXKoordinate = stXKoordinate + stTeststring
            stLesestring = stLesestring[1:]
            stTeststring = stLesestring[:1]
        if stLesestring.startswith("Y") or  stLesestring.startswith("y"):
          bNewDrawBlink = True
          iKoordinatenlinienzaehler = iKoordinatenlinienzaehler + 1
          stLesestring = stLesestring[1:]
          while stLesestring.startswith(" "):
            stLesestring = stLesestring[1:]
          if stLesestring.startswith("-"):
            stYKoordinate = stYKoordinate + "-"
            stLesestring = stLesestring[1:]
          while stLesestring.startswith(" "):
            stLesestring = stLesestring[1:]
          stTeststring = stLesestring[:1]
          while stTeststring.isdigit():
            stYKoordinate = stYKoordinate + stTeststring
            stLesestring = stLesestring[1:]
            stTeststring = stLesestring[:1]
          if stLesestring.startswith("D") or stLesestring.startswith("d"):
            stLesestring = stLesestring[1:]
            if stLesestring.endswith("\n"):
              stLesestring = stLesestring[:-1]
            if stLesestring.endswith("*"):
              stLesestring = stLesestring[:-1]
              stDraw = "D" + stLesestring
        if stXKoordinate.endswith(" "):
          stXKoordinate = stXKoordinate[:-1]
        if stYKoordinate.endswith(" "):
          stYKoordinate = stYKoordinate[:-1]
        if stXKoordinate == "":
          stXKoordinate ="0"
        if stYKoordinate == "":
          stYKoordinate ="0"  
      
        if bNewDrawBlink == True:
          
          if stXKoordinate.startswith("-"):
            stManipulierstring = stXKoordinate
            stManipulierstring = stManipulierstring[1:]
            iXKoordinate = int(stManipulierstring)
            if iXKoordinate > iXKoordinateMaxNegValue:
              iXKoordinateMaxNegValue = iXKoordinate
          
          if stYKoordinate.startswith("-"):
            stManipulierstring = stYKoordinate
            stManipulierstring = stManipulierstring[1:]
            iYKoordinate = int(stManipulierstring)
            if iYKoordinate > iYKoordinateMaxNegValue:
              iYKoordinateMaxNegValue = iYKoordinate
          
          
          iXKoordinate = int(stXKoordinate)
          iYKoordinate = int(stYKoordinate)
          
          if iXKoordinate > iXKoordinateMaxValue:
            iXKoordinateMaxValue = iXKoordinate
          if iYKoordinate > iYKoordinateMaxValue:
            iYKoordinateMaxValue = iYKoordinate
          iItemzaehler = iItemzaehler + 1
          stItemNummer = str(iItemzaehler)
          GerberFile1Processed.liGerberLayerLine[0] = iKoordinatenlinienzaehler
          GerberFile1Processed.liGerberLayerLine[1] = stItemNummer
          GerberFile1Processed.liGerberLayerLine[2] = stDraw
          GerberFile1Processed.liGerberLayerLine[3] = iXKoordinate
          GerberFile1Processed.liGerberLayerLine[4] = iYKoordinate
          GerberFile1Processed.xShift = iXKoordinateMaxNegValue
          GerberFile1Processed.yShift = iYKoordinateMaxNegValue
        
          GerberFile1Processed.liGerberLayerList.append(GerberFile1Processed.liGerberLayerLine[:])
        
          
          bNewDrawBlink = False 
        
        stXKoordinate = "" #Rücksetzten, damit sich das nicht Aufbaut
        stYKoordinate = "" #Rücksetzten, damit sich das nicht Aufbaut
        fFaktorX = 600 / iXKoordinateMaxValue
        fFaktorY = 400 / iYKoordinateMaxValue
      if fFaktorX >=  fFaktorY:
        fFaktor =  fFaktorY
      if fFaktorY >=  fFaktorX:
        fFaktor =  fFaktorX
      GerberFile1Processed.fFaktorX = fFaktorX
      GerberFile1Processed.fFaktorY = fFaktorY
      GerberFile1Processed.fFaktor = fFaktor
      GerberFile1Processed.fZoomX = GerberFile1Processed.fFaktorX
      GerberFile1Processed.fZoomY = GerberFile1Processed.fFaktorY
      GerberFile1Processed.fZoom = GerberFile1Processed.fFaktor
      GerberFile1Processed.iXMaxKoordinate = iXKoordinateMaxValue
      GerberFile1Processed.iYMaxKoordinate = iYKoordinateMaxValue
      
      del GerberFile1Processed.liGerberLayerList[0]
      iXKoordinate = 0
      iYKoordinate = 0
      GerberFile1Processed.iGerberLayerListLen = len(GerberFile1Processed.liGerberLayerList)

      GerberFile1.Datei.close()
      
    stXKoordinate = ""
    stYKoordinate = ""
    stTeststring = ""
    iXKoordinate = 0
    iXKoordinateAlt = 0
    iYKoordinate = 0
    iYKoordinateAlt = 0
    iXKoordinateMaxValue = 1
    iYKoordinateMaxValue = 1
    iXKoordinateMaxNegValue = 1
    iYKoordinateMaxNegValue = 1
    Lesestring = ""
    stLesestring = ""
    stDraw = ""
    tuKoordinatentupel =("", 0, 0, 0, 0)
    iLinienzaehler = 0
    iKoordinatenlinienzaehler = 0
    liGerberLayerLineLocal = [0, "", "", 0, 0,]
    bNewDrawBlink = False
    iItemzaehler = 0

    
    if DrillFile1.stPfad != "":
      DrillFile1.Datei = open(DrillFile1.stPfad, "rt")
      while True:
        stLesestring = DrillFile1.Datei.readline()
        if len(stLesestring) ==0:
          break # EOF wenn lesezeile nicht mehr kommt.
        iLinienzaehler = iLinienzaehler + 1
        if stLesestring.startswith("T"): # indizes for a drill file
          stDraw = "T"
        #if stLesestring.startswith("G01"): # setting linear mode, maybe, koordinates will follow
          #stLesestring = stLesestring[3:]
        if stLesestring.startswith("X") or  stLesestring.startswith("x"):
          bNewDrawBlink = True
          iKoordinatenlinienzaehler = iKoordinatenlinienzaehler + 1
          stLesestring = stLesestring[1:]
          while stLesestring.startswith(" "):
            stLesestring = stLesestring[1:]
          if stLesestring.startswith("-"):
            stXKoordinate = stXKoordinate + "-"
            stLesestring = stLesestring[1:]
          while stLesestring.startswith(" "):
            stLesestring = stLesestring[1:]
          stTeststring = stLesestring[:1]
          while stTeststring.isdigit():
            stXKoordinate = stXKoordinate + stTeststring
            stLesestring = stLesestring[1:]
            stTeststring = stLesestring[:1]
        if stLesestring.startswith("Y") or  stLesestring.startswith("y"):
          bNewDrawBlink = True
          iKoordinatenlinienzaehler = iKoordinatenlinienzaehler + 1
          stLesestring = stLesestring[1:]
          while stLesestring.startswith(" "):
            stLesestring = stLesestring[1:]
          if stLesestring.startswith("-"):
            stYKoordinate = stYKoordinate + "-"
            stLesestring = stLesestring[1:]
          while stLesestring.startswith(" "):
            stLesestring = stLesestring[1:]
          stTeststring = stLesestring[:1]
          while stTeststring.isdigit():
            stYKoordinate = stYKoordinate + stTeststring
            stLesestring = stLesestring[1:]
            stTeststring = stLesestring[:1]
        if stXKoordinate.endswith(" "):
          stXKoordinate = stXKoordinate[:-1]
        if stYKoordinate.endswith(" "):
          stYKoordinate = stYKoordinate[:-1]
        if stXKoordinate == "":
          stXKoordinate ="0"
        if stYKoordinate == "":
          stYKoordinate ="0"  
      
        if bNewDrawBlink == True:
          
          if stXKoordinate.startswith("-"):
            stManipulierstring = stXKoordinate
            stManipulierstring = stManipulierstring[1:]
            iXKoordinate = int(stManipulierstring)
            if iXKoordinate > iXKoordinateMaxNegValue:
              iXKoordinateMaxNegValue = iXKoordinate
          
          if stYKoordinate.startswith("-"):
            stManipulierstring = stYKoordinate
            stManipulierstring = stManipulierstring[1:]
            iYKoordinate = int(stManipulierstring)
            if iYKoordinate > iYKoordinateMaxNegValue:
              iYKoordinateMaxNegValue = iYKoordinate
          
          
          iXKoordinate = int(stXKoordinate)
          iYKoordinate = int(stYKoordinate)
          
          if iXKoordinate > iXKoordinateMaxValue:
            iXKoordinateMaxValue = iXKoordinate
          if iYKoordinate > iYKoordinateMaxValue:
            iYKoordinateMaxValue = iYKoordinate
          
          iItemzaehler = iItemzaehler + 1
          stItemNummer = str(iItemzaehler)
          DrillFile1Processed.liGerberLayerLine[0] = iKoordinatenlinienzaehler
          DrillFile1Processed.liGerberLayerLine[1] = stItemNummer
          DrillFile1Processed.liGerberLayerLine[2] = stDraw
          DrillFile1Processed.liGerberLayerLine[3] = iXKoordinate
          DrillFile1Processed.liGerberLayerLine[4] = iYKoordinate
          DrillFile1Processed.xShift = iXKoordinateMaxNegValue
          DrillFile1Processed.yShift = iYKoordinateMaxNegValue
        
          DrillFile1Processed.liGerberLayerList.append(DrillFile1Processed.liGerberLayerLine[:])
        
          
          bNewDrawBlink = False 
        
        stXKoordinate = "" #Rücksetzten, damit sich das nicht Aufbaut
        stYKoordinate = "" #Rücksetzten, damit sich das nicht Aufbaut
        
        fFaktorX = 600 / iXKoordinateMaxValue
        fFaktorY = 400 / iYKoordinateMaxValue
      if fFaktorX >=  fFaktorY:
        fFaktor =  fFaktorY
      if fFaktorY >=  fFaktorX:
        fFaktor =  fFaktorX
      DrillFile1Processed.fFaktorX = fFaktorX
      DrillFile1Processed.fFaktorY = fFaktorY
      DrillFile1Processed.fFaktor = fFaktor
      DrillFile1Processed.fZoomX = DrillFile1Processed.fFaktorX
      DrillFile1Processed.fZoomY = DrillFile1Processed.fFaktorY
      DrillFile1Processed.fZoom = DrillFile1Processed.fFaktor
      DrillFile1Processed.xShift = iXKoordinateMaxNegValue
      DrillFile1Processed.yShift = iYKoordinateMaxNegValue
        
      
      del DrillFile1Processed.liGerberLayerList[0]
      iXKoordinate = 0
      iYKoordinate = 0
      DrillFile1Processed.iGerberLayerListLen = len(DrillFile1Processed.liGerberLayerList)

      DrillFile1.Datei.close()
     
     #Redraw
  def RedrawDisplay():
    
    if GerberFile1Processed.bShowBlinks == True:
      buShowBlinks.configure(text = "Hide Blinks")
    if GerberFile1Processed.bShowBlinks == False:
      buShowBlinks.configure(text = "Show Blinks")
    if GerberFile1Processed.bShowMoves == True:
      buShowMoves.configure(text = "Hide Moves")
    if GerberFile1Processed.bShowMoves == False:
      buShowMoves.configure(text = "Show Moves")
    if GerberFile1Processed.bShowDraws == True:
      buShowDraws.configure(text = "Hide Draws")
    if GerberFile1Processed.bShowDraws == False:
      buShowDraws.configure(text = "Show Draws")
      
    ClearDisplay()
    GerbDisplay()
    
  #ZoomPlus
  def ZoomPlusDisplay():
  
    GerberFile1Processed.fZoomX = GerberFile1Processed.fZoomX * 1.5
    GerberFile1Processed.fZoomY = GerberFile1Processed.fZoomY * 1.5
    GerberFile1Processed.fZoom = GerberFile1Processed.fZoom *1.5
    DrillFile1Processed.fZoomX = DrillFile1Processed.fZoomX * 1.5
    DrillFile1Processed.fZoomY = DrillFile1Processed.fZoomY * 1.5
    DrillFile1Processed.fZoom = DrillFile1Processed.fZoom *1.5
    ClearDisplay()
    GerbDisplay()
    
  
  
  
  #ZoomMinus
  def ZoomMinusDisplay():
  
    GerberFile1Processed.fZoomX = GerberFile1Processed.fZoomX / 1.5
    GerberFile1Processed.fZoomY = GerberFile1Processed.fZoomY / 1.5
    GerberFile1Processed.fZoom = GerberFile1Processed.fZoom / 1.5
    DrillFile1Processed.fZoomX = DrillFile1Processed.fZoomX / 1.5
    DrillFile1Processed.fZoomY = DrillFile1Processed.fZoomY / 1.5
    DrillFile1Processed.fZoom = DrillFile1Processed.fZoom / 1.5
    ClearDisplay()
    GerbDisplay()
  
  #Autozoom
  def AutozoomDisplay():
  
    GerberFile1Processed.fZoomX = GerberFile1Processed.fFaktorX
    GerberFile1Processed.fZoomY = GerberFile1Processed.fFaktorY
    GerberFile1Processed.fZoom = GerberFile1Processed.fFaktor
    DrillFile1Processed.fZoomX = DrillFile1Processed.fFaktorX
    DrillFile1Processed.fZoomY = DrillFile1Processed.fFaktorY
    DrillFile1Processed.fZoom = DrillFile1Processed.fFaktor
    GerberFile1Processed.bShowMoves = False
    GerberFile1Processed.bShowDraws = True
    GerberFile1Processed.bShowBlinks = True
    DrillFile1Processed.bShowBlinks = True
    
    if GerberFile1Processed.bShowBlinks == True:
      buShowBlinks.configure(text = "Hide Blinks")
    if GerberFile1Processed.bShowBlinks == False:
      buShowBlinks.configure(text = "Show Blinks")
    if GerberFile1Processed.bShowMoves == True:
      buShowMoves.configure(text = "Hide Moves")
    if GerberFile1Processed.bShowMoves == False:
      buShowMoves.configure(text = "Show Moves")
    if GerberFile1Processed.bShowDraws == True:
      buShowDraws.configure(text = "Hide Draws")
    if GerberFile1Processed.bShowDraws == False:
      buShowDraws.configure(text = "Show Draws")
      
    
    
    ClearDisplay()
    GerbDisplay()
    
  
  def ClearDisplay():
    
    caDisplay.delete("Draw", "Move", "Blink", "Drill")
  
  # dummy Funktion
  def KeyF1pressed(dummy):
    ZoomPlusDisplay()
    
  # dummy Funktion
  def KeyF2pressed(dummy):
    ZoomMinusDisplay()
  
  # dummy Funktion
  def KeyF3pressed(dummy):
    RedrawDisplay()
    
  # dummy Funktion
  def KeyHomepressed(dummy):
    AutozoomDisplay()
    
  # dummy Funktion
  def KeyDeletepressed(dummy):
    ClearDisplay()

  def ToggleDraws():
    if GerberFile1Processed.bShowDraws == False:
      GerberFile1Processed.bShowDraws = True
      buShowDraws.configure(text = "Hide Draws")
      RedrawDisplay()
      return()
    if GerberFile1Processed.bShowDraws == True:
      GerberFile1Processed.bShowDraws = False
      buShowDraws.configure(text = "Show Draws")
      RedrawDisplay()
      return()

  def ToggleMoves():
    if GerberFile1Processed.bShowMoves == False:
      GerberFile1Processed.bShowMoves = True
      buShowMoves.configure(text = "Hide Moves")
      RedrawDisplay()
      return()
    if GerberFile1Processed.bShowMoves == True:
      GerberFile1Processed.bShowMoves = False
      buShowMoves.configure(text = "Show Moves")
      RedrawDisplay()
      return()
      
  def ToggleBlinks():
    if GerberFile1Processed.bShowBlinks == False:
      GerberFile1Processed.bShowBlinks = True
      buShowBlinks.configure(text = "Hide Blinks")
      RedrawDisplay()
      return()
    if GerberFile1Processed.bShowBlinks == True:
      GerberFile1Processed.bShowBlinks = False
      buShowBlinks.configure(text = "Show Blinks")
      RedrawDisplay()
      return()

  def ToggleDrills():
    
    if DrillFile1Processed.bShowDrills == False:
      DrillFile1Processed.bShowDrills = True
     
      buShowDrills.configure(text = "Hide Drills")
      RedrawDisplay()
      return()
    if DrillFile1Processed.bShowDrills == True:
      DrillFile1Processed.bShowDrills = False
      
      buShowDrills.configure(text = "Show Drills")
      RedrawDisplay()
      return() 
      
  def ToggleSyncronise():
    
    if DrillFile1Processed.bSyncronise == False:
      DrillFile1Processed.bSyncronise = True
    
      buSyncron.configure(text = "UnSyncron")
      RedrawDisplay()
      return()
    if DrillFile1Processed.bSyncronise == True:
      DrillFile1Processed.bSyncronise = False
    
      buSyncron.configure(text = "Syncron")
      RedrawDisplay()
      return() 
  
    


  #Displayfenster
  DisplayWindow = tkinter.Tk()
  DisplayWindow.title("Display Gerber (GerbAnalyse B3)")

  # DisplayRahmen for Buttons
  DisplayRahmen1 = Frame(DisplayWindow, background = "#002040")
  DisplayRahmen1.pack(side = TOP, fill = X)

  #DisplayRahmen for side Buttons and canvas
  DisplayRahmen2 = Frame(DisplayWindow, background = "#002040")
  DisplayRahmen2.pack(side = TOP, fill = X)
  
  #DisplayRahmen for Side Buttons right
  DisplayRahmen2a = Frame(DisplayRahmen2, background = "#002040")
  DisplayRahmen2a.pack(side = RIGHT, fill = X)
  
  #DisplayRahmen for Canvas
  DisplayRahmen2b = Frame(DisplayRahmen2, background = "#002040")
  DisplayRahmen2b.pack(side = RIGHT, fill = X)

  # Canvas fuer display
  scrollbar1Wag = Scrollbar(DisplayRahmen2a, orient=HORIZONTAL) 
  scrollbar1Wag.pack(side= BOTTOM, fill=X)

  scrollbar1Senk = Scrollbar(DisplayRahmen2a) 
  scrollbar1Senk.pack(side= RIGHT, fill=Y)


  caDisplay = Canvas(DisplayRahmen2a, width=800, height=500, background="white", scrollregion=(0, 0, 20000, 20000))
  caDisplay.config(yscrollcommand=scrollbar1Senk.set, xscrollcommand=scrollbar1Wag.set)
  caDisplay.pack(side= RIGHT)
  scrollbar1Senk.config(command=caDisplay.yview)
  scrollbar1Wag.config(command=caDisplay.xview)

  # Button Close
  buCloseDisplay = tkinter.Button(DisplayRahmen1, text = "Close", background = "#304000", foreground = "#FFFF5F", command = DisplayWindowClose)
  buCloseDisplay.pack(side = RIGHT)
  
  # Button Redraw
  buRedrawDisplay = tkinter.Button(DisplayRahmen1, text = "Redraw (F3)", background = "#304000", foreground = "#FFFF5F", command = RedrawDisplay)
  buRedrawDisplay.pack(side = RIGHT)
  
  
  # Button ZoomMinus
  buZoomMinusDisplay = tkinter.Button(DisplayRahmen1, text = "Zoom - (F2)", background = "#304000", foreground = "#FFFF5F", command = ZoomMinusDisplay)
  buZoomMinusDisplay.pack(side = RIGHT)
  
  
  # Button ZoomPlus
  buZoomPlusDisplay = tkinter.Button(DisplayRahmen1, text = "Zoom + (F1)", background = "#304000", foreground = "#FFFF5F", command = ZoomPlusDisplay)
  buZoomPlusDisplay.pack(side = RIGHT)
  
  
  # Button AutoZoom
  buAutoZoomDisplay = tkinter.Button(DisplayRahmen1, text = "Auto Zoom (Home)", background = "#304000", foreground = "#FFFF5F", command = AutozoomDisplay)
  buAutoZoomDisplay.pack(side = RIGHT)
  
  
  # Button Clear Display
  buClearDisplay = tkinter.Button(DisplayRahmen1, text = "Clear Display (Del)", background = "#304000", foreground = "#FFFF5F", command = ClearDisplay)
  buClearDisplay.pack(side = RIGHT)
  
  # Button Schow Blinks
  buShowBlinks = tkinter.Button(DisplayRahmen1, text = "Hide Blinks", background = "#304000", foreground = "#FFFF5F", command = ToggleBlinks)
  buShowBlinks.pack(side = RIGHT)
  
  # Button Schow Moves
  buShowMoves = tkinter.Button(DisplayRahmen1, text = "Show Moves", background = "#304000", foreground = "#FFFF5F", command = ToggleMoves)
  buShowMoves.pack(side = RIGHT)
  
  # Button Schow Draws
  buShowDraws = tkinter.Button(DisplayRahmen1, text = "Hide Draws", background = "#304000", foreground = "#FFFF5F", command = ToggleDraws)
  buShowDraws.pack(side = RIGHT)
  
  # Button Schow Drills
  buShowDrills = tkinter.Button(DisplayRahmen1, text = "Hide Drills", background = "#304000", foreground = "#FFFF5F", command = ToggleDrills)
  buShowDrills.pack(side = RIGHT)
  
   # Button Syncronise
  buSyncron = tkinter.Button(DisplayRahmen2b, text = "Syncronise", background = "#304000", foreground = "#FFFF5F", command = ToggleSyncronise)
  buSyncron.pack(side = LEFT)
  
  if GerberFile1Processed.bShowBlinks == True:
    buShowBlinks.configure(text = "Hide Blinks")
  if GerberFile1Processed.bShowBlinks == False:
    buShowBlinks.configure(text = "Show Blinks")
  if GerberFile1Processed.bShowMoves == True:
    buShowMoves.configure(text = "Hide Moves")
  if GerberFile1Processed.bShowMoves == False:
    buShowMoves.configure(text = "Show Moves")
  if GerberFile1Processed.bShowDraws == True:
    buShowDraws.configure(text = "Hide Draws")
  if GerberFile1Processed.bShowDraws == False:
    buShowDraws.configure(text = "Show Draws")
  if DrillFile1Processed.bShowDrills == True:
    buShowDrills.configure(text = "Hide Drills")
  if DrillFile1Processed.bShowDrills == False:
    buShowDrills.configure(text = "Show Drills")
  if DrillFile1Processed.bSyncronise == False:
    buSyncron.configure(text = "Syncronise")
  if DrillFile1Processed.bSyncronise == True:
    buSyncron.configure(text = "UnSyncron")
  
  DisplayWindow.bind("<F1>", KeyF1pressed)
  DisplayWindow.bind("<F2>", KeyF2pressed)
  DisplayWindow.bind("<F3>", KeyF3pressed)
  DisplayWindow.bind("<Home>", KeyHomepressed)
  DisplayWindow.bind("<Delete>", KeyDeletepressed)
  GerbProcessing()
  AutozoomDisplay()
  GerbDisplay()

def FileDiscrimination(Target):
   
  if Target.iTCodes == 0 :
    Target.iGerber = Target.iGerber + 1
    
    
    
    
  if Target.iDCodes > 0 :
    Target.iGerber = Target.iGerber + 1
   
  
  if Target.iDCodesTP > 0 :
    Target.iGerber = Target.iGerber + 1
   
    
  if Target.iGerber247dzeilen > 0 :
    Target.iGerber247d = Target.iGerber247d + 1
    Target.iGerber = Target.iGerber + 1
  
  if Target.iGerber247xzeilen > 0 :
    Target.iGerber247x = Target.iGerber247x + 1
    Target.iGerber = Target.iGerber + 1
   
  
  #Ausgewertet?
  if Target.iMCodes2Line == Target.iZeilenzahl :
    Target.iGerber = Target.iGerber + 1
  
  #Ausgewertet?
  if Target.iMCodes30Line == Target.iZeilenzahl :
    Target.iExcellon = Target.iExcellon + 1
    Target.iDrill = Target.iDrill + 1
   
    
  if Target.bProzProz1000Code == True :
    Target.iSiebMeyer1000 = Target.iSiebMeyer1000 + 1
    Target.iDrill = Target.iDrill + 1
    
  if Target.bProzProz3000Code == True :
    Target.iSiebMeyer3000 = Target.iSiebMeyer3000 + 1
    Target.iDrill = Target.iDrill + 1
   
  if Target.iMCodes71 > 0 :
    Target.iExcellon = Target.iExcellon + 1
    Target.iDrill = Target.iDrill + 1
  
    
  if Target.iMCodes72 > 0 :
    Target.iExcellon = Target.iExcellon + 1
    Target.iDrill = Target.iDrill + 1
   
  if Target.iTCodes > 0 :
    Target.iDrill = Target.iDrill + 1
    
    
  if Target.bProzCode == True:
    Target.iExcellon = Target.iExcellon + 1
    Target.iDrill = Target.iDrill + 1

  if Target.iDrill > 0 :
    Target.bDrill = True
   
    
  if Target.iGerber247x > 0 :
    Target.bGerber247x = True
    Target.bGerber = True
    
  if Target.iGerber247d > 0 :
    Target.bGerber247d = True
    Target.bGerber = True
  
  if Target.bGerber247x == True and Target.bGerber247d == True :
    Target.bGerber247d = False
		
    
  if Target.iExcellon > 0 : 
    Target.bExcellon = True
    Target.bDrill = True
    
  if Target.iSiebMeyer1000 > 0 :
    Target.bSiebMeyer1000 = True
    Target.bDrill = True
    Target.bGerber247d = False
    Target.bGerber247x = False
    Target.bExcellon = False
    Target.bGerber = False
  
  if Target.iSiebMeyer3000 > 0 :
    Target.bSiebMeyer3000 = True
    Target.bDrill = True
    Target.bGerber247d = False
    Target.bGerber247x = False
    Target.bExcellon = False
    Target.bGerber = False
	
  
  Target.iBogusIndex = int(Target.iZeilenzahl / 20)
  if Target.iIgnoredLines > Target.iBogusIndex : 
    Target.bBogusIndex = True


# Hauptfenster
Hauptfenster = tkinter.Tk()
Hauptfenster.title ("GerbAnalyse B3")
name = ""
class GerberFile1(BasGerbAnalyseDaten):
  pass
GerberFile1.__init__(GerberFile1)
GerberFile1.Init(GerberFile1)
class GerberFile1Processed(GerberLayer):
 pass
GerberFile1Processed.__init__(GerberFile1Processed)
GerberFile1Processed.Init(GerberFile1Processed)

class DrillFile1(BasGerbAnalyseDaten):
  pass

DrillFile1.__init__(DrillFile1)
DrillFile1.Init(DrillFile1)
class DrillFile1Processed(GerberLayer):
  pass
DrillFile1Processed.__init__(DrillFile1Processed)
DrillFile1Processed.Init(DrillFile1Processed)

# Rahmen für Dateiwahl und Ende
Rahmen1 = Frame(Hauptfenster, background = "#002040")
Rahmen1.pack(side = TOP, fill = X)

#Rahmen2
Rahmen2 = Frame(Hauptfenster, background = "#002040")
Rahmen2.pack(side = TOP, fill = X)

#Rahmen3
Rahmen3 = Frame (Hauptfenster, background = "#002040")
Rahmen3.pack(side = TOP, fill = X)

#Rahmen4
Rahmen4 = Frame (Hauptfenster, background = "#002040")
Rahmen4.pack(side = TOP, fill = X)

#Rahmen5
Rahmen5 = Frame (Hauptfenster, background = "#002040")
Rahmen5.pack(side = TOP, fill = X)

#Rahmen6
Rahmen6 = Frame (Hauptfenster, background = "#002040")
Rahmen6.pack(side = TOP, fill = X)

#Rahmen7
Rahmen7 = Frame (Hauptfenster, background = "#002040")
Rahmen7.pack(side = TOP, fill = X)

#Rahmen8
Rahmen6 = Frame (Hauptfenster, background = "#002040")
Rahmen6.pack(side = TOP, fill = X)

#Rahmen9
Rahmen7 = Frame (Hauptfenster, background = "#002040")
Rahmen7.pack(side = TOP, fill = X)


# Button datei Gerber
buttfunkt1 = tkinter.Button(Rahmen1, text = "Choose Gerber file", background = "#304000", foreground = "#FFFF5F", command = Dateiwahl)
buttfunkt1.pack(side = LEFT)

# Button Analyse Gerber
butGerberAnalyse = tkinter.Button(Rahmen1, text = "Analyse Gerber", background = "#304000", foreground = "#FFFF5F", command = AnalyseGerber)
butGerberAnalyse.pack(side = LEFT)

# Button Save  Gerber Analyse
buSaveAnalyse = tkinter.Button(Rahmen6, text = "Save Analyse", background = "#304000",  foreground = "#FFFF5F", command = saveanalyse)
buSaveAnalyse.pack(side = LEFT)


#Pfadanzeige Gerber
PfadanzeigeGerber = tkinter.Entry(Rahmen2, width = 100, background = "#408000",foreground = "#FFFF5F")
PfadanzeigeGerber.pack(side = LEFT, fill = X)
PfadanzeigeGerber.insert(0, "Gerber Path: Empty")
                           


#Pfadanzeige Drill
PfadanzeigeDrill = tkinter.Entry(Rahmen4, width = 100, background = "#408000",foreground = "#FFFF5F")
PfadanzeigeDrill.pack(side = LEFT, fill = X)
PfadanzeigeDrill.insert(0, "Drill Path: Empty")

# Button datei Drill
butDrillFile = tkinter.Button(Rahmen3, text = "Choose drill file", background = "#304000", foreground = "#FFFF5F", command = Drillfile)
butDrillFile.pack(side = LEFT)

# Button Analyse Drill
butGerberAnalyse = tkinter.Button(Rahmen3, text = "Analyse Drill", background = "#304000", foreground = "#FFFF5F", command = AnalyseDrill)
butGerberAnalyse.pack(side = LEFT)

# Button Ende
b = tkinter.Button(Rahmen1, text = "Ende", background = "#304000", foreground = "#FFFF5F", command = ende)
b.pack(side = RIGHT)

# Button About
buttonabout = tkinter.Button(Rahmen1, text = "About", background = "#304000", foreground = "#FFFF5F", command = about)
buttonabout.pack(side = RIGHT)

# buton Display
buDisplay = tkinter.Button(Rahmen6, text = "Display", background = "#304000", foreground = "#FFFF5F", command = DisplayWindowOeffnen)
buDisplay.pack(side = RIGHT)


# Button Clear
buttonclear = tkinter.Button(Rahmen6, text = "Clear", background = "#304000", foreground = "#FFFF5F", command = clear)
buttonclear.pack(side = LEFT)

# Listbox für Gerber


# Auch wenn der Scrollbar dem Textfeld zugeordnet ist,
# so wird er doch in das übergeordnete Fenster eingebaut!
scrollbarx = Scrollbar(Rahmen5, orient=HORIZONTAL) 
scrollbarx.pack(side= BOTTOM, fill=X)
scrollbary = Scrollbar(Rahmen5) 
scrollbary.pack(side= RIGHT, fill=Y)
Listanzeige1 = tkinter.Listbox(Rahmen5, width = 100, height = 10, background = "#408000",foreground = "#FFFF5F")
Listanzeige1.pack(side= LEFT)

Listanzeige1.config(yscrollcommand=scrollbary.set)
scrollbary.config(command=Listanzeige1.yview)
Listanzeige1.config(xscrollcommand=scrollbarx.set)
scrollbarx.config(command=Listanzeige1.xview)



# Listbox für Analyse

# Auch wenn der Scrollbar dem Textfeld zugeordnet ist,
# so wird er doch in das übergeordnete Fenster eingebaut!
scrollbarx = Scrollbar(Rahmen7, orient=HORIZONTAL) 
scrollbarx.pack(side= BOTTOM, fill=X)
scrollbary = Scrollbar(Rahmen7) 
scrollbary.pack(side= RIGHT, fill=Y)
Listanzeige2 = tkinter.Listbox(Rahmen7, width = 100, height = 10, background = "#408000",foreground = "#FFFF5F")
Listanzeige2.pack(side= LEFT)

Listanzeige2.config(yscrollcommand=scrollbary.set)
scrollbary.config(command=Listanzeige2.yview)
Listanzeige2.config(xscrollcommand=scrollbarx.set)
scrollbarx.config(command=Listanzeige2.xview)


# endlosschleife
Hauptfenster.mainloop()

