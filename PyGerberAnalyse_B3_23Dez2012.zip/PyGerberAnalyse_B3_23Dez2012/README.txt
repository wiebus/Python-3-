About PyGerbAnalyse_B3.py:
Author: Bernd Wiebus, Uedem, Germany, 23 December 2012
License: GNU Lesser General Public License, http://www.gnu.org/licenses/lgpl-3.0.en.html
THERE IS NO WARRANTY FOR THIS SOFTWARE AND DOCUMENTATION!
Questions, suggestions and improvements are welcome at: bernd.wiebus@gmx.de

Instructions:
Python 3 has to be installed.
PyGerbAnalyse_B3.py is the "program" itsself.
ClassDefBasicAnalysisResults.py and ClassDefGerberLayer.py are class definitions for this program. 
PyGerbAnalyse_B3.py, ClassDefBasicAnalysisResults.py and ClassDefGerberLayer.py should be in the same folder.

Start PyGerbAnalyse_B3.py with your Python3.x interpreter.

