# -*- coding: utf-8 -*-
# ClassDefGerberLayer.py
# Python 3 Classdefinition
# Autor: Dipl.-Ing. Bernd Wiebus
# Uedem den 12. Oktober 2012
# Alpha-Version / GNU-GPL

class GerberLayer(object):  #Listen und Hilfsvariablen um Gerberdaten zwischenzuspeichern.
  iItemNo = 0
  iGerberLayerListLen = 0
  iXMaxKoordinate = 0
  iYMaxKoordinate = 0
  fFaktorX = 1.0
  fFaktorY = 1.0
  fFaktor = 1.0
  fZoomX = 1.0
  fZoomY = 1.0
  fZoom = 1.0
  xShift = 0
  yShift = 0
  
    
  bShowMoves = False
  bShowDraws = True
  bShowBlinks = True
  bShowDrills = True
  bSyncronise = False
  
  liGerberLayerLine = [0, "", "", 0, 0,] # List with processed gerber data: Item No., "Aperture", "Draw type", x Value, y Value
  liGerberLayerList  = [liGerberLayerLine] # List of lists with processed gerber data)
  
  def __init__(self): # Constructor
        pass

  def Init(self): # Setting to default values

    itItemNo = 0
    iGerberLayerListLen = 0
    fFaktorX = 1.0
    fFaktorY = 1.0
    fFaktor = 1.0
    fZoomX = 1.0
    fZoomY = 1.0
    fZoom = 1.0
    xShift = 0
    yShift = 0
    iXMaxKoordinate = 0
    iYMaxKoordinate = 0
    liGerberLayerLine = [0, "", "", 0, 0,] 
    liGerberLayerList  = [liGerberLayerLine]
    bShowMoves = False
    bShowDraws = True
    bShowBlinks = True
    bShowDrills = True
    bSyncronise = False

