# -*- coding: utf-8 -*-
# ClassDefBasicAnalysisResults.py
# Python 3 Classdefinition
# Autor: Dipl.-Ing. Bernd Wiebus
# Uedem den 18. September 2012
# Alpha-Version / GNU-GPL

class BasGerbAnalyseDaten(object):  #Basic class for analysis results

    #General definitions
    stPfad =""                                 #The path to the File
    iZeilenzahl =int(0)                            #Counter for line numbers
    iExcellon = int(0)                             #Counter for indizes to be an Excellon drill file.
    iGerber247d = int(0)                #Counter for indizes to be a Gerber247d file.
    iGerber247x = int(0)                #Counter for indizes to be a Gerber247x file.
    iSiebMeyer1000 = int(0)          #Counter for indizes to be a SiebMeyer1000 drill file.
    iSiebMeyer3000 = int(0)         #Counter for indizes to be a SiebMeyer3000 drill file.
    iGerber = int(0)                     #Counter for indizes to be a Gerber File
    iDrill = int(0)                      #Counter FOR indizes TO be a drill file
    bExcellon = False                  #Marker if recognised as Excellon drill file
    iBogusIndex = int(0)
    bGerber247d = False              #Marker if recognised as Gerber247d file
    bGerber247x = False               #Marker if recognised as Gerber247x file
    bSiebMeyer1000 = False        #Marker if recognised as Sieb&Meyer 1000 drill file
    bSiebMeyer3000 = False         #Marker if recognised as Sieb&Meyer 3000 drill file
    bGerber = False                 #Marker if recognised as Gerber file
    bDrill = False                  #Marker if recognised as drill file
    bCircleMakro = False             #Marker if circle makros at the File
    bCircleMode = False              #Marker, if CW/CCW AND single/multiquadrand aktivated
    bNegXCoordinates = False     #Marker, if some x coordinates are negative.
    bNegYCoordinates = False      #Marker, if some y coordinates are negative.
    bBogusIndex = False
    bBogusIndex2 = False
    

    #Gerber Definitions
    iIgnoredLines =int(0)     # Counter for ignored lines
    iGerber247dzeilen =int(0)     #Counter for lines ending with *
    iGerber247xzeilen =int(0)       #Counter for lines starting with % and ending with *%. Exeption aperture Macros
    iNCodes =int(0)                 #Counter for lines starting with N
    iDCodes =int(0)                  #Counter for lines starting with D
    iDCodesTP =int(0)                #Counter for D-Codes with Tool prepare command leading
    iDCode01 =int(0)                 #Counter for lines starting with D01 (Exposure on)
    iDCode02 =int(0)                  #Counter for lines starting with D02 (Exposure off)
    iDCode03 =int(0)             #Counter for lines starting with D03 (Blinks)
    iGCodes =int(0)                    #Counter for lines starting with G, exeption G54
    iMCodes0 =int(0)                  #Counter for lines with M0 or M00 (Startcode)
    iMCodes0Line =int(0)             #Linenumber of the last File start code
    iMCodes1 =int(0)                 #Counter for lines with M1 or M01  (Stoppcode)
    iMCodes2 =int(0)                 #Counter for lines starting with M2 or M02 (Endcode)
    iMCodes2Line =int(0)             #Linenumber of the last File End code
    iMCodes =int(0)                   #'Counter for all M-Codes
    iKoordinatenD01 =int(0)          #Counter for coordinate lines with D1 (Exposure off) 
    iKoordinatenD02 =int(0)         #'Counter for coordinate lines with D2 (Exposure on)
    iKoordinatenD03 =int(0)         #Counter for coordinate lines with D3 (Blink)
    iKoordinatenModal =int(0)      #Counter for coordinate lines without D code (Modal)
    iKoordinatenLines =int(0)        #Counter for all coordinate lines
    stModeD =""                         #Keeps the last D-Code (Mode)
    iGCode00 =int(0)                    #Counter for Move comando 
    iGCode01 =int(0)                      #Counter for switches to linear interpolation (1x scala)
    iGCode02 =int(0)                      #Counter for switches to clockwise interpolation.
    iGCode03 =int(0)                      #Counter for switches to counterclockwise interpolation.
    iGCode04 =int(0)                     #Counter for commend lines (G04)
    iGCode10 =int(0)                      #Counter for switches to linear interpolation (10x scala)
    iGCode11 =int(0)                      #Counter for switches to linear interpolation (0,1x scala)
    iGCode12 =int(0)                       #Counter for switches to linear interpolation (0,01x scala)
    iGCode54 =int(0)                      #For counting tool prepare command (G54, 247d)
    iGCode70 =int(0)                      #For counting 247D inch definitions
    iGCode71 =int(0)                      #For counting 247D mm definitions
    iGCode74 =int(0)                      #Counter for switching from full circle to qarter circle, Circle Tool
    iGCode75 =int(0)                      #Counter for enabling clockwise interpolation (qartercircle), Circle Tool
    iGCode90 =int(0)                     #For counting 247D absolute definitions
    iGCode91 =int(0)                       #For counting 247D incremental definitions
    iMoin =int(0)                             #For counting 247X inch definitions
    iMomm =int(0)                          #For counting 247x mm definitions
    iFS =int(0)                             #For counting 247x FS statements.
    iFSAbsolute =int(0)                   #For counting 247x absolute statements
    iFSIncremental =int(0)              #For counting 247x incremental statements
    #fXSkalierfaktor AS Float                 #For preserving the last X Skalierfactor.
    #fYSkalierfaktor AS Float                 #For preserving the last Y Skalierfactor.
    stFS =""                                 #For preserving the last 247x FS statement.
    iApertDef =int(0)                     #Counter for aperture definitions
    iApertDefMac =int(0)               #Counter for aperture macros
    bEinheitinch = False               #Marker for inch Mode.
    bEinheitmm = False                #Marker for mm Mode.
    bStoppStat = False                  #Marker for Stop mode
    bStoppEnd = False                    #Marker for file end mode.
    bAbsolute = False                     #Marker for absolute mode.
    bIncremental = False               #Marker for incremental Mode.
    bModeD01 = False                   #Marker for D01-Code mode 
    bModeD02 = False                   #Marker for D02-Code mode 
    bModeD03 = False                   #Marker for D03-Code mode 
    bExposeWarning = False         #Marker for Expose Warnings.
    bUnitWarning = False             #Marker for Unit Warning (not defined yet at some coordinates)
    bAbsIncWarning = False          #Marker for Abs-Inc Data Warning (not defined yet at some coordinates)
    bGCode01 = False                   #Marker for G01 1x linear mode
    bGCode02 = False                   #Marker for G02 clockwise mode
    bGCode03 = False                   #Marker for G03 counterclockwise mode
    bGCode74 = False                   #Marker for G74 single quadrant mode
    bGCode75 = False                   #Marker for G75 multiquadrant mode
    bGCode10 = False                   #Marker for G10 10x linear mode
    bGCode11 = False                   #Marker for G11 0,1x linear mode
    bGCode12 = False                   #Marker for G12 0,01x linear mode


    #Drill Definitions
    iProzCode =int(0)   #Excellon: Counter for % Signs.
    iTDef =int(0)   #Excellon: Counter for T-Code definitions
    iTCodes =int(0)   #Excellon: Counter for T-Code Lines
    stTNamDef = ""       #Excellon: String with T-Code Names 
    iMCodes30 =int(0)   #Excellon & SiebMeyer: Program end/Rewind
    iMCodes30Line =int(0)   #Linenumber of M30 Code (End/Rewind)
    iMCodes48 =int(0)   #Excellon: Counter for Program Header Start
    iMCodes48Line =int(0)   #Excellon: Line number of Program Header
    iMCodes95 =int(0)   #Excellon: Counter for Program Header End
    iMCodes95Line =int(0)   #Excellon: Line number of Program Header End
    iMCodes71 =int(0)   #Excellon: Counter for metric definition
    iMCodes72 =int(0)   #Excellon: Counter for inch definition.
    bProzCode = False   #   # = FALSE   'Single % at first Line.
    bProzProz1000Code = False   #Single %%1000 at first Line (Sieb&Meyer).
    bProzProz3000Code = False   #Single %%3000 at first Line (Sieb&Meyer).
    bExcelHeader = False   #Marker for Excellon header mode
    bExcelHeaderProzOff = False   #Marker for Ecellon header mode switchoff by a % statement. Empirical.
    bExcelMetric = False   #Marker for Excellon metric mode
    bExcelInch = False   #Marker for Excellon inch mode  
    bProzCode = False   #Marker if first line is only %
    bStartProzCode = False #Marker for lines starting with "%".

    def __init__(self): # Constructor
        pass

    def Init(self): # Setting to default values

        #General definitions
        self.stPfad =""                                 #The path to the File
        self.iZeilenzahl =int(0)                            #Counter for line numbers
        self.iExcellon = int(0)                             #Counter for indizes to be an Excellon drill file.
        self.iGerber247d = int(0)                #Counter for indizes to be a Gerber247d file.
        self.iGerber247x = int(0)                #Counter for indizes to be a Gerber247x file.
        self.iSiebMeyer1000 = int(0)          #Counter for indizes to be a SiebMeyer1000 drill file.
        self.iSiebMeyer3000 = int(0)         #Counter for indizes to be a SiebMeyer3000 drill file.
        self.iGerber = int(0)                     #Counter for indizes to be a Gerber File
        self.iDrill = int(0)                      #Counter FOR indizes TO be a drill file
        self.iBogusIndex = int(0)
        self.bExcellon = False                  #Marker if recognised as Excellon drill file
        self.bGerber247d = False              #Marker if recognised as Gerber247d file
        self.bGerber247x = False               #Marker if recognised as Gerber247x file
        self.bSiebMeyer1000 = False        #Marker if recognised as Sieb&Meyer 1000 drill file
        self.bSiebMeyer3000 = False         #Marker if recognised as Sieb&Meyer 3000 drill file
        self.bGerber = False                 #Marker if recognised as Gerber file
        self.bDrill = False                  #Marker if recognised as drill file
        self.bCircleMakro = False             #Marker if circle makros at the File
        self.bCircleMode = False              #Marker, if CW/CCW AND single/multiquadrand aktivated
        self.bNegXCoordinates = False     #Marker, if some x coordinates are negative.
        self.bNegYCoordinates = False      #Marker, if some y coordinates are negative.
        self.bBogusIndex = False
        self.bBogusIndex2 = False

        #Gerber Definitions
        self.iIgnoredLines =int(0)     # Counter for ignored lines
        self.iGerber247dzeilen =int(0)     #Counter for lines ending with *
        self.iGerber247xzeilen =int(0)       #Counter for lines starting with % and ending with *%. Exeption aperture Macros
        self.iNCodes =int(0)                 #Counter for lines starting with N
        self.iDCodes =int(0)                  #Counter for lines starting with D
        self.iDCodesTP =int(0)                #Counter for D-Codes with Tool prepare command leading
        self.iDCode01 =int(0)                 #Counter for lines starting with D01 (Exposure on)
        self.iDCode02 =int(0)                  #Counter for lines starting with D02 (Exposure off)
        self.iDCode03 =int(0)             #Counter for lines starting with D03 (Blinks)
        self.iGCodes =int(0)                    #Counter for lines starting with G, exeption G54
        self.iMCodes0 =int(0)                  #Counter for lines with M0 or M00 (Startcode)
        self.iMCodes0Line =int(0)             #Linenumber of the last File start code
        self.iMCodes1 =int(0)                 #Counter for lines with M1 or M01  (Stoppcode)
        self.iMCodes2 =int(0)                 #Counter for lines starting with M2 or M02 (Endcode)
        self.iMCodes2Line =int(0)             #Linenumber of the last File End code
        self.iMCodes =int(0)                   #'Counter for all M-Codes
        self.iKoordinatenD01 =int(0)          #Counter for coordinate lines with D1 (Exposure off) 
        self.iKoordinatenD02 =int(0)         #'Counter for coordinate lines with D2 (Exposure on)
        self.iKoordinatenD03 =int(0)         #Counter for coordinate lines with D3 (Blink)
        self.iKoordinatenModal =int(0)      #Counter for coordinate lines without D code (Modal)
        self.iKoordinatenLines =int(0)        #Counter for all coordinate lines
        self.stModeD =""                         #Keeps the last D-Code (Mode)
        self.iGCode00 =int(0)                    #Counter for Move comando 
        self.iGCode01 =int(0)                      #Counter for switches to linear interpolation (1x scala)
        self.iGCode02 =int(0)                      #Counter for switches to clockwise interpolation.
        self.iGCode03 =int(0)                      #Counter for switches to counterclockwise interpolation.
        self.iGCode04 =int(0)                     #Counter for commend lines (G04)
        self.iGCode10 =int(0)                      #Counter for switches to linear interpolation (10x scala)
        self.iGCode11 =int(0)                      #Counter for switches to linear interpolation (0,1x scala)
        self.iGCode12 =int(0)                       #Counter for switches to linear interpolation (0,01x scala)
        self.iGCode54 =int(0)                      #For counting tool prepare command (G54, 247d)
        self.iGCode70 =int(0)                      #For counting 247D inch definitions
        self.iGCode71 =int(0)                      #For counting 247D mm definitions
        self.iGCode74 =int(0)                      #Counter for switching from full circle to qarter circle, Circle Tool
        self.iGCode75 =int(0)                      #Counter for enabling clockwise interpolation (qartercircle), Circle Tool
        self.iGCode90 =int(0)                     #For counting 247D absolute definitions
        self.iGCode91 =int(0)                       #For counting 247D incremental definitions
        self.iMoin =int(0)                             #For counting 247X inch definitions
        self.iMomm =int(0)                          #For counting 247x mm definitions
        self.iFS =int(0)                             #For counting 247x FS statements.
        self.iFSAbsolute =int(0)                   #For counting 247x absolute statements
        self.iFSIncremental =int(0)              #For counting 247x incremental statements
        #fXSkalierfaktor AS Float                 #For preserving the last X Skalierfactor.
        #fYSkalierfaktor AS Float                 #For preserving the last Y Skalierfactor.
        self.stFS =""                                 #For preserving the last 247x FS statement.
        self.iApertDef =int(0)                     #Counter for aperture definitions
        self.iApertDefMac =int(0)               #Counter for aperture macros
        self.bEinheitinch = False               #Marker for inch Mode.
        self.bEinheitmm = False                #Marker for mm Mode.
        self.bStoppStat = False                  #Marker for Stop mode
        self.bStoppEnd = False                    #Marker for file end mode.
        self.bAbsolute = False                     #Marker for absolute mode.
        self.bIncremental = False               #Marker for incremental Mode.
        self.bModeD01 = False                   #Marker for D01-Code mode 
        self.bModeD02 = False                   #Marker for D02-Code mode 
        self.bModeD03 = False                   #Marker for D03-Code mode 
        self.bExposeWarning = False         #Marker for Expose Warnings.
        self.bUnitWarning = False             #Marker for Unit Warning (not defined yet at some coordinates)
        self.bAbsIncWarning = False          #Marker for Abs-Inc Data Warning (not defined yet at some coordinates)
        self.bGCode01 = False                   #Marker for G01 1x linear mode
        self.bGCode02 = False                   #Marker for G02 clockwise mode
        self.bGCode03 = False                   #Marker for G03 counterclockwise mode
        self.bGCode74 = False                   #Marker for G74 single quadrant mode
        self.bGCode75 = False                   #Marker for G75 multiquadrant mode
        self.bGCode10 = False                   #Marker for G10 10x linear mode
        self.bGCode11 = False                   #Marker for G11 0,1x linear mode
        self.bGCode12 = False                   #Marker for G12 0,01x linear mode

        #Drill Definitions
        self.iProzCode =int(0)   #Excellon: Counter for % Signs.
        self.iTDef =int(0)   #Excellon: Counter for T-Code definitions
        self.iTCodes =int(0)   #Excellon: Counter for T-Code Lines
        self.stTNamDef = ""       #Excellon: String with T-Code Names 
        self.iMCodes30 =int(0)   #Excellon & SiebMeyer: Program end/Rewind
        self.iMCodes30Line =int(0)   #Linenumber of M30 Code (End/Rewind)
        self.iMCodes48 =int(0)   #Excellon: Counter for Program Header Start
        self.iMCodes48Line =int(0)   #Excellon: Line number of Program Header
        self.iMCodes95 =int(0)   #Excellon: Counter for Program Header End
        self.iMCodes95Line =int(0)   #Excellon: Line number of Program Header End
        self.iMCodes71 =int(0)   #Excellon: Counter for metric definition
        self.iMCodes72 =int(0)   #Excellon: Counter for inch definition.
        self.bProzCode = False   #   # = FALSE   'Single % at first Line.
        self.bProzProz1000Code = False   #Single %%1000 at first Line (Sieb&Meyer).
        self.bProzProz3000Code = False   #Single %%3000 at first Line (Sieb&Meyer).
        self.bExcelHeader = False   #Marker for Excellon header mode
        self.bExcelHeaderProzOff = False   #Marker for Ecellon header mode switchoff by a % statement. Empirical.
        self.bExcelMetric = False   #Marker for Excellon metric mode
        self.bExcelInch = False   #Marker for Excellon inch mode  
        self.bProzCode = False   #Marker if first line is only %
        self.bStartProzCode = False #Marker for lines starting with "%".



