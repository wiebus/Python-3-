#!/usr/bin/env python3
# -*- coding: utf-8 -*-


# Programm : KiCad-CaseSensitiveLibCure_RevC_21Mar_2014.py
# Python 3 Programm; Tool for converting KiCad schematic from non case sensitive into case sensitive.
# Autor: Dipl.-Ing. Bernd Wiebus
# Uedem / 21 March 2014
# GNU-GPL

import tkinter as tk
from tkinter.filedialog import *
#from time import gmtime, strftime
#import datetime
import sys

class File(object):
  """
  Defining an objekt which contains all information about the used files and variables. 
  """
  
  
  stPath = "" #Path to the actual schematic file. preset: empty
  iZeilenzahl = 0 # Counter for lines
  bSheetmarker = False
  bSheetnamemarker = False
  stZwischenspeicherPath = ""
  #stSubsheetname =""
  iPosition1 = 0 
  stPosition1 = ""
  iPosition2 = 0 
  stPosition2 = ""
  iPosition3 = 0 
  iComponentCounter = 0 # Number of of components found in librarys
  stPosition3 = ""
  bErstePosition = False
  bZweitePosition = False
  iListlen = 0
  iLibListlen = 0
  zaehler1 = 0
  liListline = ["", ""]
  liZwischenspeicher = [liListline]
  liLibraryList = [liListline] # List of Librarys
  liNotFound = [] # List of not found symbols
  iNotFound = 0 # Number of not found symbols
  liComponentsInLibrary = [liListline] # List of components found in librarys
  ililenZwischenspeicher = 0
  iLiLenLibrary = 0
  SemaphorGerman = False
  SemaphorEnglish = True
  stSchematic1Leer = "Schematic choosen: Empty"
  stSchematic1insert = "Schematic choosen:"
  #stSchematic2 = "insert before position "
  
  
  Programmname ="PyKicad-CaseSensitiveLibCure_RevC_21Mar2014.py\n" #Defining.....
  Programmzweck ="Purpose: Converts old KiCad schematic files with pure upper case component names.\n" #Defining.....
  Programmversion ="Version: Alpha Version C \n"   #Defining.....
  Programmdatum ="from 21 March 2014 \n"  #Defining.....
  Pythonversion = "Written for Python 3.1. \n"   #Defining.....
  Programmautor ="Author: Bernd Wiebus alias DL1EIC \n"  #Defining.....
  ProgrammautorMail ="E-Mail: bernd.wiebus@gmx.de \n" #How to contact the author
  Programmlizenz ="GNU-GPL NO WARRANTY!\n"   #Defining.....
  
  stHelpLine1 ="With \u0022 Choose File \u0022  you chose a schematic (*.sch) file you want to convert.\n" #Defining.....
  stHelpLine2 ="With \u0022 Choose Kicad Library  \u0022  you choose one or more library (.lib) files.\n" #Defining.....
  stHelpLine3 ="If you want to convert:\n"   #Defining.....
  stHelpLine4 ="Press Button \u0022 Convert \u0022. \n"  #Defining.....
  stHelpLine5 ="The converted file gets the suffix \u0022 -UpConverted.sch \u0022.\n"   #Defining.....
  stHelpLine6 ="Known problems: subschematics have to be converted by there own.\n"  #Defining.....
  stHelpLine7 ="Symbols starting with \u0022 ~ \u0022 will not be recognized.\n" #HDefining.......
  stHelpLine8 ="Do not forget to rename the files manually for proper working subschematics!\n"   #Defining...
  stHelpLine9 ="If you encounter problems: Please contact the author at:\n"   #Defining...
  stHelpLine10 ="bernd.wiebus@gmx.de\n"   #Defining...
  stHelpLine11 ="++++++++++++++++++++++++++++++++++++\n"   #Defining.....
  
  
  
  def __init__(self):
    pass


def LocaGerman():
  """This subrocram switches all localisation variables to German localisation."""
  File.SemaphorGerman = True
  File.SemaphorEnglish = False
  
  buSchematicFile.configure(text = "Wähle KiCad .sch Schaltplan Datei")
  buEnd.configure(text = "Ende")
  buttonabout.configure(text = "Über")
  buttonhelp.configure(text = "Hilfe")
  buLibraryChoose.configure(text = "Wähle KiCad Symbolbibliothek .lib Dateien")
  buConvertOld2New.configure(text = "Umwandeln alt zu neu")
  
  if File.stPath == "":
    laPathToSchematic.configure(text = "Pfad: Leer")
  else:
    laPathToSchematic.configure(text = ("Pfad: " + File.stPath))
	
  File.Programmname ="PyKicad-CaseSensitiveLibCure_RevC_21Mar2014.py\n" #Defining.....
  File.Programmzweck ="Programmzweck: Konvertiert alte KiCad Schaltpläne vor BZR4646 mit reinen Großbuchstaben in Symbolnamen.\n" #Defining.....
  File.Programmversion ="Version: Alpha Version C \n"   #Defining.....
  File.Programmdatum ="vom 21 März 2014 \n"  #Defining.....
  File.Pythonversion = "Geschrieben für Python 3.1. \n"   #Defining.....
  File.Programmautor ="Autor: Bernd Wiebus alias DL1EIC \n"  #Defining.....
  File.ProgrammautorMail ="E-Mail: bernd.wiebus@gmx.de \n" #How to contact the author
  File.Programmlizenz ="GNU-GPL NO WARRANTY!\n"   #Defining.....
  
  stHelpLine1 ="Mit \u0022 Wähle Schaltplan Datei \u0022  wählen Sie eine zu konvetierende Schaltplan (.sch) Datei.\n" #Defining.....
  stHelpLine2 ="Mit \u0022 Wähle Symbolbibliothek  \u0022  wählen Sie eine oder mehrere Symbolbibliotheken (.lib) Dateien.\n" #Defining.....
  stHelpLine3 ="Zum Umwandeln drücken sie dann \n"   #Defining.....
  stHelpLine4 ="die Schaltfläche Press Button \u0022 Umwandeln alt zu neu \u0022. \n"  #Defining.....
  stHelpLine5 ="Die umgewandelte Datei erhält die Endung: \u0022 -Converted.sch \u0022.\n"   #Defining.....
  stHelpLine6 ="Bekannte Probleme: Unterschaltpläne müssen separat umgewandelt werden.\n"  #Defining.....
  stHelpLine7 ="Symbole, die eine Tilde \u0022 ~ \u0022 enthalten, werden nicht erkannt.\n" #HDefining.......
  stHelpLine8 ="Vergessen Sie nicht die Dateien zum Schluss von Hand umzubenennen.!\n"   #Defining...
  stHelpLine9 ="Wenn Sie Probleme haben, so kontaktieren Sie mich bitte unter:\n"   #Defining...
  stHelpLine10 ="bernd.wiebus@gmx.de\n"   #Defining...
  stHelpLine11 ="++++++++++++++++++++++++++++++++++++\n"   #Defining.....
  
  

def LocaBritish():
  """This subrocram switches all localisation variables to British localisation."""
  File.SemaphorGerman = False
  File.SemaphorEnglish = True
  

  buSchematicFile.configure(text = "Choose Kicad .sch file")
  buEnd.configure(text = "End")
  buttonabout.configure(text = "About")
  buttonhelp.configure(text = "Help")
  buLibraryChoose.configure(text = "Choose Kicad Library .lib file")
  buConvertOld2New.configure(text = "Convert old to new")
  if File.stPath == "":
    laPathToSchematic.configure(text = "Path: Empty")
  else:
    laPathToSchematic.configure(text = ("Path: " + File.stPath))
  
  File.Programmname ="PyKicad-CaseSensitiveLibCure_RevA_25Feb2014.py\n" #Defining.....
  File.Programmzweck ="Purpose: Converts old KiCad schematic files with pure upper case component names.\n" #Defining.....
  File.Programmversion ="Version: Alpha Version \n"   #Defining.....
  File.Programmdatum ="from 20 March 2014 \n"  #Defining.....
  File.Pythonversion = "Written for Python 3.1. \n"   #Defining.....
  File.Programmautor ="Author: Bernd Wiebus alias DL1EIC \n"  #Defining.....
  File.ProgrammautorMail ="E-Mail: bernd.wiebus@gmx.de \n" #How to contact the author
  File.Programmlizenz ="GNU-GPL NO WARRANTY!\n"   #Defining.....
  
  stHelpLine1 ="With \u0022 Choose File \u0022  you chose a schematic (*.sch) file you want to convert.\n" #Defining.....
  stHelpLine2 ="With \u0022 Choose Kicad Library  \u0022  you choose one or more library (.lib) files.\n" #Defining.....
  stHelpLine3 ="If you want to convert:\n"   #Defining.....
  stHelpLine4 ="Press Button \u0022 Convert to new \u0022. \n"  #Defining.....
  stHelpLine5 ="The converted file gets the suffix \u0022 -Converted.sch \u0022.\n"   #Defining.....
  stHelpLine6 ="Known problems: subschematics have to be converted by there own.\n"  #Defining.....
  stHelpLine7 ="Symbols starting with \u0022 ~ \u0022 will not be recognized.\n" #HDefining.......
  stHelpLine8 ="Do not forget to rename the files manually for proper working subschematics!\n"   #Defining...
  stHelpLine9 ="If you encounter problems: Please contact the author at:\n"   #Defining...
  stHelpLine10 ="bernd.wiebus@gmx.de\n"   #Defining...
  stHelpLine11 ="++++++++++++++++++++++++++++++++++++\n"   #Defining.....


def about():
  """
  The subprogramm "about()" shows general info about the programm, 
  its purpose and the author.
  """
  if File.SemaphorEnglish == True:
    stButtonclipboard = "Copy info into clipboard"
  if File.SemaphorGerman == True:
    stButtonclipboard = "Kopiere Info in Zwischenablage"
  
  #Funktion close Aboutwindow
  def aboutok():
    """
    the subprogramm "aboutok()" is a subprogramm of the subprogramm "about()".
    Its funktion is just to close the window, which was opened by "about()".
    """
    
    Aboutwindow.destroy()
        
  def clipboardfill(): # copies the about text to the clipboard
    Aboutwindow.clipboard_clear() #First: clear clipboard!
    Aboutwindow.clipboard_append(Programmabout) #second: Write value to clipboard!
   
  
  Programmabout = File.Programmname + File.Programmzweck + File.Programmversion + File.Programmdatum + File.Pythonversion + File.Programmautor + File.ProgrammautorMail + File.Programmlizenz #And now putting all strings together.
  Aboutwindow = tk.Tk() #create Window
  Aboutwindow.title ("PyKicad-CaseSensitiveLibCure_RevA_25Feb2014.py --ABOUT--")
  Aboutanzeige = tk.Label(Aboutwindow, text = Programmabout, background = "#002040",foreground = "#FFFF5F")
  Aboutanzeige.pack(side = TOP, fill = X)
  # Rahmen für Aboutfenster OK Button
  AboutRahmen1 = Frame(Aboutwindow, background = "#002040")
  AboutRahmen1.pack(side = TOP, fill = X)
  # Button Aboutok
  buttonaboutok = tk.Button(AboutRahmen1, text = "OK", background = "#304000",  foreground = "#FFFF5F", command = aboutok) #closing about window
  buttonaboutok.pack(side = TOP)
  buttonclipboard = tk.Button(AboutRahmen1, text = stButtonclipboard, background = "#304000",  foreground = "#FFFF5F", command = clipboardfill) #copying the abouttext to clibboard.
  buttonclipboard.pack(side = TOP)
  
  
def notfound():
  """
  The subprogramm "notfound()" shows that some symbols were not found.
  """
  if File.SemaphorEnglish == True:
    stButtonclipboard = "Copy list into clipboard"
    stNotFound = "Symbols not found!"
    stNotFoundInList1 = "There are \n"
    stNotFoundInList2 = "symbols not found \n"
    stNotFoundInList3 = "in the librarys! \n"
    stNotFoundInList4 = "Maybe, some are multiple counted. \n"
    stNotFoundInList5 = "The list of this symbols can be put to the clibboard!\n"
    stReport2 = "Transformed Schematic saved to file with  \u0022 -Converted.sch \u0022 suffix.\n"
    stListStart = "Begin listing: \n"
    stListEnde = "End of list.\n"
    
  if File.SemaphorGerman == True:
    stButtonclipboard = "Kopiere Liste in Zwischenablage"
    stNotFound = "Symbole, die nicht gefunden wurden!"
    stNotFoundInList1 = "Es wurden \n"
    stNotFoundInList2 = "Symbole NICHT in den \n"
    stNotFoundInList3 = "Bibliotheken gefunden! \n"
    stNotFoundInList4 = "Mehrfachzählungen sind möglich. \n"
    stNotFoundInList5 = "Die Liste der Symbole kann in die Zwischenablage kopiert werden! \n"
    stReport2 = "Gewandelter Schaltplan in Datei mit \u0022 -Converted.sch \u0022 Endung gespeichert.\n"
    stListStart = "Listenanfang: \n"
    stListEnde = "Ende der Liste.\n"
    
    
  stMissingSymbols = ""
  stNotFoundInList = stNotFoundInList1 + (str(File.iNotFound)) + "\n" + stNotFoundInList2 + stNotFoundInList3
  stNotFoundInList = stNotFoundInList + stNotFoundInList4 + stNotFoundInList5
  stNotFoundInList = stNotFoundInList + stReport2
  
  iNotFoundListLen = len(File.liNotFound)
  for iIndex in range(0, iNotFoundListLen, 1):
    stMissingSymbols = stMissingSymbols + File.liNotFound[iIndex] + "\n"
  stNotFoundList = stNotFoundInList + stListStart + stMissingSymbols + stListEnde
 
    
  #Funktion close NotFoundWindow
  def NotFoundWindowClose():
    """
    the subprogramm "helpclose()" is a subprogramm of the subprogramm "help()".
    Its funktion is just to close the window, which was opened by "help()".
    """
    
    NotFoundWindow.destroy()
  
  def clipboardfillNFList(): # copies the Not Found List to the clipboard
    NotFoundWindow.clipboard_clear() #First: clear clipboard!
    NotFoundWindow.clipboard_append(stNotFoundList) #second: Write value to clipboard!  
    
  
  NotFoundWindow = tk.Tk() #create Window
  NotFoundWindow.title (stNotFound)
  laNotFoundSymbols = tk.Label(NotFoundWindow, text = stNotFoundInList, background = "#002040",foreground = "#FFFF5F")
  laNotFoundSymbols.pack(side = TOP, fill = X)
  # Frame for NotFoundWindow OK Button
  NotFoundWindowFrame1 = Frame(NotFoundWindow, background = "#002040")
  NotFoundWindowFrame1.pack(side = TOP, fill = X)
  # Button NotFoundWindow ok
  buNotFoundOK = tk.Button(NotFoundWindowFrame1, text = "OK", background = "#304000",  foreground = "#FFFF5F", command = NotFoundWindowClose) #closing NotFound Window
  buNotFoundOK.pack(side = TOP)
  # Button to copy the not found list to the clippoard.
  buNotFoundToClipboard = tk.Button(NotFoundWindowFrame1, text = stButtonclipboard, background = "#304000",  foreground = "#FFFF5F", command = clipboardfillNFList) #copying the NotFound List to clibboard.
  buNotFoundToClipboard.pack(side = TOP)


def report():
  """
  The subprogramm "report()"
  """
  if File.SemaphorEnglish == True:
    
    stReport1 = "All Symbols found! \n"
    stReport2 = "New schematic in file with \u0022 -Converted.sch \u0022 ending saved.\n"
    
    
  if File.SemaphorGerman == True:
    stReport1 = "Alle Symbolse gefunden! \n"
    stReport2 = "Gewandelter Schaltplan in Datei mit \u0022 -Converted.sch \u0022 Endung gespeichert.\n"
    
  stReport = stReport1 + stReport2
 
    
  #Funktion close ReportWindow
  def ReportWindowClose():
    """
    the subprogramm "ReportWindowClose()" is a subprogramm of the subprogramm "report()".
    Its funktion is just to close the window, which was opened by "report()".
    """
    
    ReportWindow.destroy()
  
  
  
  ReportWindow = tk.Tk() #create Window
  ReportWindow.title ("Report")
  laReport = tk.Label(ReportWindow, text = stReport, background = "#002040",foreground = "#FFFF5F")
  laReport.pack(side = TOP, fill = X)
  # Frame for ReportWindow OK Button
  ReportWindowFrame1 = Frame(ReportWindow, background = "#002040")
  ReportWindowFrame1.pack(side = TOP, fill = X)
  # Button ReportWindow ok
  buReportWindowOK = tk.Button(ReportWindowFrame1, text = "OK", background = "#304000",  foreground = "#FFFF5F", command = ReportWindowClose) #closing NotFound Window
  buReportWindowOK.pack(side = TOP)
  



def helptext():
  """
  The subprogramm "help()" shows a help text.
  """
  if File.SemaphorEnglish == True:
    stButtonclipboard = "Copy info into clipboard"
    stHelp = "Help"
    
  if File.SemaphorGerman == True:
    stButtonclipboard = "Kopiere Info in Zwischenablage"
    stHelp = "Hilfe"
    
  Helpwindow = tk.Tk() #create Window
  Helpwindow.title ("Help")
  Helpanzeige = tk.Label(Helpwindow, text = stHelptext, background = "#002040",foreground = "#FFFF5F")
  Helpanzeige.pack(side = TOP, fill = X)
  # Rahmen für helpfenster OK Button
  HelpRahmen1 = Frame(Helpwindow, background = "#002040")
  HelpRahmen1.pack(side = TOP, fill = X)
  # Button helpok
  buttonhelpok = tk.Button(HelpRahmen1, text = "OK", background = "#304000",  foreground = "#FFFF5F", command = helpclose) #closing help window  buttonhelpok.pack(side = TOP)
  
  buttonclipboard = tk.Button(HelpRahmen1, text = stButtonclipboard, background = "#304000",  foreground = "#FFFF5F", command = clipboardfillhelp) #copying the abouttext to clibboard.
  buttonclipboard.pack(side = TOP)


  #Funktion close Help window
  def helpclose():
    """
    the subprogramm "helpclose()" is a subprogramm of the subprogramm "help()".
    Its funktion is just to close the window, which was opened by "help()".
    """
    
    Helpwindow.destroy()
        
  def clipboardfillhelp(): # copies the help text to the clipboard
    Helpwindow.clipboard_clear() #First: clear clipboard!
    Helpwindow.clipboard_append(stHelptext) #second: Write value to clipboard!
  stHelptext = File.stHelpLine1 + File.stHelpLine2 + File.stHelpLine3 + File.stHelpLine4 + File.stHelpLine5 + File.stHelpLine6 + File.stHelpLine7 + File.stHelpLine8 #And now putting all strings together.
  stHelptext = stHelptext + File.stHelpLine9 + File.stHelpLine10 + File.stHelpLine11
  Helpwindow = tk.Tk() #create Window
  Helpwindow.title ("Help")
  Helpanzeige = tk.Label(Helpwindow, text = stHelptext, background = "#002040",foreground = "#FFFF5F")
  Helpanzeige.pack(side = TOP, fill = X)
  # Rahmen für helpfenster OK Button
  HelpRahmen1 = Frame(Helpwindow, background = "#002040")
  HelpRahmen1.pack(side = TOP, fill = X)
  # Button helpok
  buttonhelpok = tk.Button(HelpRahmen1, text = "OK", background = "#304000",  foreground = "#FFFF5F", command = helpclose) #closing about window
  buttonhelpok.pack(side = TOP)
  buttonclipboard = tk.Button(HelpRahmen1, text = stButtonclipboard, background = "#304000",  foreground = "#FFFF5F", command = clipboardfillhelp) #copying the abouttext to clibboard.
  buttonclipboard.pack(side = TOP)
  
def ChooseSchematicFile():
  """
  The subprogram "ChooseSchematicFile()" is for choose an existing schematic file.
  """
  global name
  name = ""
  File.iListlen = 0
  File.ililenZwischenspeicher = len(File.liZwischenspeicher)
  for iIndex in range(0, File.ililenZwischenspeicher -1, 1): #Clear the old list
      del File.liZwischenspeicher[0]
  name = askopenfilename(filetypes=[("Kicad-Schematics", ".sch"),("All files", "*")])
  if name: #Nur Wahr, wenn Pfad gewählt wurde. Sonst Leerstring/Tupel
    File.stPath = name
  laPathToSchematic["text"] = File.stPath 
  
  return()
  
  
def ChooseLibraryFile():
  """
  The subprogram "ChooseLibraryFile()" is for choose existing library files and read it.
  """
  global name
  File.iLibListlen = 0
  File.iComponentCounter = 0
  iNumberOfSymbols = len(File.liComponentsInLibrary)
  for iIndex in range(0, iNumberOfSymbols -1, 1): #Clear the old list
    del File.liComponentsInLibrary[0] 
  File.iLiLenLibrary  = len(File.liLibraryList)
  for iIndex in range(0, File.iLibListlen -1, 1): #Clear the old list
    del File.liLibraryList[0]
  name = askopenfilenames(filetypes=[("Kicad-Libraries", ".lib"),("All files", "*")])
  if name: #Nur Wahr, wenn Pfad gewählt wurde. Sonst Leerstring/Tupel
    File.liLibraryList = name
    File.iLibListlen = len(File.liLibraryList)
    #print("LibListe: ", File.liLibraryList)
    LibraryList.delete(0, END) #Neues Listimng
    for iIndex in range(0, File.iLibListlen, 1):
      stLibName = File.liLibraryList[iIndex]
      LibraryList.insert(END, stLibName) #Neues Listimng
      LibraryList.yview(END) #Anzeige zum Ende 
      ReadFile = open(stLibName, mode="rt")
      while True:
        Lesezeile = ReadFile.readline()
        #print("Lesezeile: ", Lesezeile)
        File.iZeilenzahl = File.iZeilenzahl +1
        if len(Lesezeile) ==0:
          break # EOF wenn lesezeile nicht mehr kommt.
        stComponentName = ""
        stComponentNameUpper = ""
        tuComponentName = ("","")
        if Lesezeile.startswith("DEF "):
          stWorkline = Lesezeile
          #print("stWorkline Pos1: ", stWorkline)
          stWorkline = stWorkline[4:]
          while not stWorkline.startswith(" "):
            stComponentName = stComponentName + stWorkline[:1]
            stWorkline = stWorkline[1:]
          #print("ComponentName: ", "-" + stComponentName + "-")
          stComponentNameUpper = stComponentName.upper()
          tuComponentName = (stComponentNameUpper, stComponentName)
          File.liComponentsInLibrary.append(tuComponentName)
      ReadFile.close()
          
  #print("component Liste: ", File.liComponentsInLibrary)
  return()

# Function Convert
def Convert():
  if File.stPath == "":
    return()
  File.liNotFound[:] = [] #Clear the old list
  File.iNotFound = 0 # Counter reset to zero.
  stWritepath = File.stPath[:-4] + "-Converted.sch"
  #print("Schreibpfaad: ", stWritepath)
  boComponentFlag = False
  ReadFile = open(File.stPath, mode="rt")
  WriteFile = open(stWritepath, mode="w")
  while True:
    Lesezeile = ReadFile.readline()
    if len(Lesezeile) ==0:
      break # EOF wenn lesezeile nicht mehr kommt.
    stWriteLine = Lesezeile
    if Lesezeile.startswith("$Comp"):
      boComponentFlag = True
    if Lesezeile.startswith("$EndComp"):
      boComponentFlag = False
    iWorkline = len(Lesezeile)
    iWorkcounter = 0
    if Lesezeile.startswith("L ") and boComponentFlag == True:
      stWorkline = Lesezeile
      #print("stWorkline Pos1: ", stWorkline)
      stWorkline = stWorkline[2:]
      iWorkcounter = 2
      stComponentNameSchematic = ""
      while not stWorkline.startswith(" "):
        stComponentNameSchematic = stComponentNameSchematic + stWorkline[:1]
        iWorkcounter = iWorkcounter + 1
        stWorkline = stWorkline[1:]
      iComponentListLen = len(File.liComponentsInLibrary)
      for iIndex in range(0, iComponentListLen, 1):
        tuComponent = File.liComponentsInLibrary[iIndex]
        boNotFound = False
        #print("tupel0: ", tuComponent[0])
        #print("tupel1: ", tuComponent[1])
        if stComponentNameSchematic == tuComponent[0]:
          boNotFound = True
          stComponentNameSchematic = tuComponent[1]
      if boNotFound == False: # If no fitting name found....
        iLowerCaseCounter = 0
        for stTestChar in stComponentNameSchematic: # Testing for new Type (lower case)..... 
          if stTestChar.islower():
            iLowerCaseCounter = iLowerCaseCounter +1 # increment, if lower case found.
        if iLowerCaseCounter == 0:  # If no lower case found, means old type.....  
          File.liNotFound.append(stComponentNameSchematic) # ....then add to list
          File.iNotFound = File.iNotFound + 1 # increment Counter of not found symbols
		  
      stWriteLine = "L " + stComponentNameSchematic
      iLenWorkLine = len(stWorkline)
      for iIndex in range(0, iLenWorkLine):
        stWriteLine = stWriteLine + stWorkline[:1]
        stWorkline = stWorkline[1:]
      #print("Zeile: ", stWriteLine)
    WriteFile.write(stWriteLine)
    
  if File.iNotFound != 0:
    notfound()
  if File.iNotFound == 0:
    report()
  ReadFile.close()
  WriteFile.close()
  
 
 
# Function save
def Save():
    global name
    File.zaehler1 = 0
    File.bSheetmarker == False
    name = File.stPath[:-4] + "Changed.sch"
    if name: #Nur Wahr, wenn Pfad gewählt wurde. Sonst Leerstring/Tupel
      stActPath = ("Path: " + name) # Only local
      Pathanzeige["text"] = stActPath # Only local
      SchematicFile = open(File.stPath, mode="rt")
      SaveFile = open(name, mode="w")
      while True:
        Lesezeile = SchematicFile.readline()
        if len(Lesezeile) ==0:
            break # EOF wenn lesezeile nicht mehr kommt.
        if Lesezeile.startswith("$Sheet"):
          File.bSheetmarker = True
          stSheetname = LibraryList.get(File.zaehler1)
          File.ililenZwischenspeicher = len(File.liZwischenspeicher)
          for iIndex in range(0, File.ililenZwischenspeicher, 1): #read list
            Listeneintrag = File.liZwischenspeicher[iIndex]
            stSheetnameRead = Listeneintrag[0]
            if stSheetnameRead == stSheetname:
              Lesezeile2 = Listeneintrag[1]
              SaveFile.write(Lesezeile2)
          File.zaehler1 = File.zaehler1 + 1
        if Lesezeile.startswith("$EndSheet"):
          File.bSheetmarker = False
        if File.bSheetmarker == False:
          if not Lesezeile.startswith("$EndSheet"):
            SaveFile.write(Lesezeile)
      SaveFile.close()
      SchematicFile.close()
        
   # newfile()

   # Funktion Button Ende
def end():
  Mainwindow.destroy()
   
# Mainwindowloop

Mainwindow = tk.Tk()
Mainwindow.title ("KiCad-CaseSensitiveLibCure_RevC_21Mar2014.py")
Mainwindow.protocol("WM_DELETE_WINDOW", end) # call end() when closing window

name = ""
IconBritish = """R0lGODlhJAAYAIQRAFIR+PgREewbItkwRNQyRtUzR+UwP+YxP9w+UOc/TdtCVOdGVOdHVOdHVelU
YP3n6ezw9////////////////////////////////////////////////////////////ywAAAAA
JAAYAAAFvmAQPE8UAWiKmo4jmqpqivRYnvEatS+ezzRg7xdhMIYxoGkZqcGSxWPgKWtOlzqnD2Bq
NJDCK1Fb9YKtyFxWzI0gEAIBs0dVr5+md3x+reuYgIAFBXSBhoeHg4WISwMDNZCRkpMijo6UmJmV
j5qdnp+gfYxLBASLo6hMpaeMdkpLCgpnaXYpryaxs2yuS2cLCwcHda+8xG2/wcNWfm1ktlEGBswQ
ELRhykbR09Vs11s6LQkJzHe9Qd9t4ePo5SEAOw=="""
IconDeutsch = """R0lGODlhJAAYAKEDAAAAAPgREfj2Ef///yH5BAEKAAMALAAAAAAkABgAAAI0hI+py+0Po5y02ouz
3jD4D4biSJbmiabqyrbuC8fyjAr2jef6zvf+DwwKh8Si8YhMKpfAAgA7"""




# Rahmen1 
Rahmen1 = Frame(Mainwindow, background = "#002040")
Rahmen1.pack(side = TOP, fill = X)

#Rahmen2
Rahmen2 = Frame(Mainwindow, background = "#002040")
Rahmen2.pack(side = TOP, fill = X)

#Rahmen3
Rahmen3 = Frame (Mainwindow, background = "#002040")
Rahmen3.pack(side = TOP, fill = X)

#Rahmen4
Rahmen4 = Frame (Mainwindow, background = "#002040")
Rahmen4.pack(side = TOP, fill = X)

#Rahmen5
Rahmen5 = Frame (Mainwindow, background = "#002040")
Rahmen5.pack(side = TOP, fill = X)



# Button choose schematic file.
buSchematicFile = tk.Button(Rahmen1, text = "Choose Kicad .sch file", background = "#304000", foreground = "#FFFF5F", command = ChooseSchematicFile)
buSchematicFile.pack(side = LEFT)

# Button End
buEnd = tk.Button(Rahmen1, text = "End", background = "#304000", foreground = "#FFFF5F", command = end)
buEnd.pack(side = RIGHT)

# Button About
buttonabout = tk.Button(Rahmen1, text = "About", background = "#304000", foreground = "#FFFF5F", command = about)
buttonabout.pack(side = RIGHT)

# Button help
buttonhelp = tk.Button(Rahmen1, text = "Help", background = "#304000", foreground = "#FFFF5F", command = helptext)
buttonhelp.pack(side = RIGHT)

#Path to schematic file
laPathToSchematic = tk.Label(Rahmen2, text = "Path: Empty", background = "#408000",foreground = "#FFFF5F")
laPathToSchematic.pack(side = LEFT, fill = X)

#Choose libraries
buLibraryChoose = tk.Button(Rahmen3, text = "Choose Kicad Library .lib file", background = "#304000",foreground = "#FFFF5F", command = ChooseLibraryFile)
buLibraryChoose.pack(side = LEFT, fill = X)


# Listbox for Schematic
# Auch wenn der Scrollbar dem Textfeld zugeordnet ist,
# so wird er doch in das übergeordnete Fenster eingebaut!
scrollbarx = Scrollbar(Rahmen4, orient=HORIZONTAL) 
scrollbarx.pack(side= BOTTOM, fill=X)
scrollbary = Scrollbar(Rahmen4) 
scrollbary.pack(side= RIGHT, fill=Y)
LibraryList = tk.Listbox(Rahmen4, width = 100, height = 10, background = "#408000",foreground = "#FFFF5F")
LibraryList.pack(side= LEFT)

LibraryList.config(yscrollcommand=scrollbary.set)
scrollbary.config(command=LibraryList.yview)
LibraryList.config(xscrollcommand=scrollbarx.set)
scrollbarx.config(command=LibraryList.xview)
LibraryList.bind("<<ListboxSelect>>", end)

# Button Convert
buConvertOld2New = tk.Button(Rahmen1, text = "Convert", background = "#304000", foreground = "#FFFF5F", command = Convert)
buConvertOld2New.pack(side = LEFT)

# Button Deutsch
IconImageDeutsch=tk.PhotoImage(master = Mainwindow, data=IconDeutsch)
buttonDeutsch = tk.Button(Rahmen5, image = IconImageDeutsch, background = "#304000", foreground = "#FFFF5F", command = LocaGerman)
buttonDeutsch.image = IconImageDeutsch
buttonDeutsch.pack(side = RIGHT)

# Button British
IconImageBritish=tk.PhotoImage(master = Mainwindow, data=IconBritish)
buttonBritish = tk.Button(Rahmen5, image = IconImageBritish, background = "#304000", foreground = "#FFFF5F", command = LocaBritish)
buttonBritish.image = IconImageBritish
buttonBritish.pack(side = RIGHT)

# Infinite mainlloop
Mainwindow.mainloop()
